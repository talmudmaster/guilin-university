package pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 封装：
 * 1、get/set
 * 2、无参构造方法
 * 3、有参构造方法
 * 4、toString
 * */
@Data
@NoArgsConstructor  //无参构造方法
@AllArgsConstructor //有参构造方法
public class User {
    private Integer id;
    private String username;
    private String sex;
    private String birthday;
    private String keyId;

    public User(Integer id, String username , String sex , String birthday) {
        this.id = id;
        this.username = username;
        this.sex = sex;
        this.birthday = birthday;
    }

    public User(String username , String sex , String birthday , String keyId) {
        this.username = username;
        this.sex = sex;
        this.birthday = birthday;
        this.keyId = keyId;
    }
}
