import cn.hutool.core.util.ObjectUtil;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.mybatis.mapper.StudentMapper;
import com.mybatis.pojo.Student;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StudentMapperTest {
    private SqlSessionFactory sqlSessionFactory;

    @Before
    public void setUp(){
        try {
            InputStream inputStream = Resources.getResourceAsStream("SqlMapConfig.xml");
            sqlSessionFactory = new SqlSessionFactoryBuilder().build( inputStream );
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void insertStudentTest(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        StudentMapper studentMapper = sqlSession.getMapper(StudentMapper.class);
        Student student = new Student();
        student.setUsername("王五");
        student.setPassword("rango");
        student.setSex("男");
        student.setBirthday("2000-09-08");
        student.setAddress("云南丽江");
        int result = studentMapper.insertStudent(student);
        if(result>0){
            System.out.println("添加成功");
        }else{
            System.out.println("添加失败");
        }
        sqlSession.commit();

    }

    @Test
    public void findAll(){
        //获取会话实例
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //获取动态代理实例
        StudentMapper studentMapper = sqlSession.getMapper(StudentMapper.class);
        List<Student> studentList =  studentMapper.findAll();
        for(Student student:studentList){
            System.out.println(student);
        }
    }

    @Test
    public void findStudentById(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        StudentMapper studentMapper = sqlSession.getMapper(StudentMapper.class);
        Student student =  studentMapper.findStudentById(10);
        if(!ObjectUtil.hasEmpty(student)){
            System.out.println(student);
        }else{
            System.out.println("没有查询到相关的记录！！！");
        }
    }

    @Test
    public void findByUserNameAndPassword(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        StudentMapper studentMapper = sqlSession.getMapper(StudentMapper.class);
        Student student = studentMapper.findByUserNameAndPassword("李四","123456");
        if(!ObjectUtil.hasEmpty(student)){
            System.out.println(student);
        }else{
            System.out.println("没有查询到相关的记录！！！");
        }
    }

    @Test
    public void findByLikeUserName(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        StudentMapper studentMapper = sqlSession.getMapper(StudentMapper.class);
        List<Student> studentList = studentMapper.findByLikeUserName("范");
        if(!ObjectUtil.hasEmpty(studentList)){
            for(Student student:studentList){
                System.out.println(student);
            }
        }else{
            System.out.println("没有查询到相关的记录！！！");
        }

    }

    @Test
    public void updateStudent(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        StudentMapper studentMapper = sqlSession.getMapper(StudentMapper.class);
        Student student = new Student();
        student.setId(7);
        student.setUsername("范傻呆");
        student.setPassword("rango62589");
        student.setSex("女");
        student.setBirthday("1982-06-08");
        student.setAddress("河南周口");
        int result = studentMapper.updateStudent(student);
        if(result>0){
            System.out.println("修改成功");
        }else{
            System.out.println("修改失败");
        }
        sqlSession.commit();
    }

    @Test
    public void deleteStudentById(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        StudentMapper studentMapper = sqlSession.getMapper(StudentMapper.class);
        int result = studentMapper.deleteStudentById(3);
        if(result>0){
            System.out.println("删除成功");
        }else{
            System.out.println("删除失败");
        }
        sqlSession.commit();
    }

    @Test
    public void countByStudent(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        StudentMapper studentMapper = sqlSession.getMapper(StudentMapper.class);
        int count = studentMapper.countByStudent();
        System.out.println("总记录数为："+count);
    }

    //分页测试
    @Test
    public void getStudentLimitTest(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        StudentMapper studentMapper = sqlSession.getMapper(StudentMapper.class);
        Map<String,Integer> map = new HashMap<String,Integer>();
        map.put("pageNum",0);
        map.put("pageSize",5);
        List<Student> studentList = studentMapper.getStudentLimit(map);
        studentList.forEach(stu -> System.out.println(stu));
    }

    //pageHelper分页测试
    @Test
    public void getStudentByPageHelperTest(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        StudentMapper studentMapper = sqlSession.getMapper(StudentMapper.class);
        Page page = PageHelper.startPage(2,5);
        List<Student> studentList = studentMapper.getStudentByPageHelper();
        //构造pageInfo对象一定是在查询操作之后
        PageInfo pageInfo = page.toPageInfo();
        System.out.println("总页数：" + pageInfo.getPages());
        System.out.println("总记录数：" + pageInfo.getTotal());
        System.out.println("当前页：" + pageInfo.getPageNum());
        System.out.println("每页显示的记录数：" + pageInfo.getPageSize());
        System.out.println("前一页：" + pageInfo.getPrePage());
        System.out.println("下一页：" + pageInfo.getNextPage());
        System.out.println("当前页的列表：" + pageInfo.getList().size());
        int nums[] = pageInfo.getNavigatepageNums();
        for (int i = 0; i < nums.length; i++) {
            System.out.println(nums[i]);
        }
        studentList.forEach(student -> System.out.println(student));
    }
}
