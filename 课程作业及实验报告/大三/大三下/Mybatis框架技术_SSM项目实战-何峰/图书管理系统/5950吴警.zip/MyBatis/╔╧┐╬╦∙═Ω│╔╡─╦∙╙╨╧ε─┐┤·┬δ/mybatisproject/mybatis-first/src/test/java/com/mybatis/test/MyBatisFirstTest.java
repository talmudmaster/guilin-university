package com.mybatis.test;

import dao.UserDao;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;
import pojo.User;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;


public class MyBatisFirstTest {
    //因为所有的操作都需要获取SqlSession实例，所有抽取成一个方法
    public SqlSession getSession() throws IOException {
        //得到配置文件的流
        InputStream inputStream = Resources.getResourceAsStream("SqlMapConfig.xml");

        //创建会话工厂SqlSessionFactory
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);

        //通过工厂得到SqlSession实例
        SqlSession sqlSession = sqlSessionFactory.openSession();
        return sqlSession;
    }

    @Test
    public void findUserId() throws IOException{
        SqlSession sqlSession = getSession();
        User user = sqlSession.selectOne("myBatisTest.findUserById",1);
        System.out.println(user.toString());
        sqlSession.close();
    }

    @Test
    public void findUserName() throws IOException{
        SqlSession sqlSession = getSession();
        User user = sqlSession.selectOne("myBatisTest.findUserByName","范呆呆");
        System.out.println(user.toString());
        sqlSession.close();
    }

    @Test
    public void findUserByLikeName() throws IOException{
        SqlSession sqlSession = getSession();
        List<User> userList = sqlSession.selectList("myBatisTest.findUserByLikeName","呆");
        System.out.println("记录数："+userList.size());
//        System.out.println(userList.toString());
        for (User user : userList) {
            System.out.println(user);
        }
        sqlSession.close();
    }

    @Test
    public void insertUser() throws IOException{
        SqlSession sqlSession = getSession();
        User user = new User(3,"范呆呆","男","2000-09-12");
        sqlSession.insert("myBatisTest.insertUser",user);
        //提交事务
        sqlSession.commit();
        System.out.println(user.getId());
        sqlSession.close();
    }

    @Test
    public void getUserList() throws IOException{
        //第一步：获得session对象
        SqlSession sqlSession = getSession();
        //方式一：getmapper
//        UserDao mapper = sqlSession.getMapper(UserDao.class);
//        List<User> userList = mapper.getUserList();
        //方式二：
        List<User> userList = sqlSession.selectList("Dao.UserDao.getUserList");
        for (User user : userList) {
            System.out.println(user);
        }
        //关闭sqlsession
        sqlSession.close();
    }


    //增删改需要提交事务
    @Test
    public void addUser() throws IOException{
        //获取sqlsession对象
        SqlSession sqlSession = getSession();
        //get取出
        UserDao mapper = sqlSession.getMapper(UserDao.class);
        int res = mapper.addUser(new User(4, "范呆呆", "男","1990-05-12"));
        if(res > 0){
            System.out.println("添加成功");
        }
        //提交事务
        sqlSession.commit();
        sqlSession.close();
    }

    //修改用户信息
    @Test
    public void updateUser() throws IOException{
        SqlSession sqlSession = getSession();
//        UserDao mapper = sqlSession.getMapper(UserDao.class);
//        mapper.updateUser(new User(1,"范","男","2000-09-07"));
        User user = new User(1,"admin","男","2000-09-07");
        user.setKeyId("84021314-cdd4-11ec-94ad-80fa5b753ab7");
        sqlSession.update("myBatisTest.updateUser",user);
        sqlSession.commit();
        sqlSession.close();
    }

    //根据id删除用户信息
    @Test
    public void deleteUser() throws IOException{
        SqlSession sqlSession = getSession();
        sqlSession.delete("myBatisTest.deleteUser",2);
//        UserDao mapper = sqlSession.getMapper(UserDao.class);
//        int i = mapper.deleteUser(4);
        sqlSession.commit();
        sqlSession.close();
    }
}
