package com.springboot.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
//当前的作用：将pojo类实例化到Spring容器中
@Component
/**
 * ConfigurationProperties：
 *  告诉SpringBoot将本类中的所有属性和配置文件中相关的配置进行绑定
 *  prefix = "yamlbean"：执行映射的前缀，表示配置文件中那些属性进行一一映射
 *  注意点：指定的前缀名必须是小写的
 *  在项目开发过程中，属性与参数的绑定操作，推荐使用此种方式
 * */
@ConfigurationProperties(prefix="yamlbean")
public class YamlBean {
    //@Value:只能是对的那个字符串类型的变量不绑定属性值
    //@Value("${name}")
    private String name;

    //@Value("${message}")
    private String message;

    //@Value("${user}")
    private User user;

    private Map<String,Object> maps;

    private String[] lagType;

    private List<Object> hobby;
}
