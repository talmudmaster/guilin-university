package com.springboot;

import com.github.pagehelper.PageInfo;
import com.springboot.pojo.Book;
import com.springboot.pojo.User;
import com.springboot.service.BookService;
import com.springboot.service.UserService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import javax.annotation.Resource;
import java.util.List;

@SpringBootTest //表示当前类是一个SpringBoot的测试类
public class SpringBootMybatisTest {
//    @Resource
    @Autowired
    private UserService userService;

//    @Test
//    public void getFindByAllTest(){
//        List<User> userList = userService.findAllUser();
//        userList.forEach(user -> System.out.println(user));
//    }

    @Test
    public void getSaveTest(){
        User user = new User();
        user.setUsername("张三");
        user.setSex("男");
        user.setAddress("广西桂林");
        System.out.println(userService.addUser(user));
    }

//    @Test
//    public void getUpdateByIdTest(){
//        User user = new User();
//        user.setId(37);
//        user.setSex("男");
//        userService.updateUser(user);
//    }

    @Test
    public void getLoginTest(){
        User user = userService.userLogin("张三","广西桂林");
        if(user != null){
            System.out.println("登录成功");
        }else{
            System.out.println("登录失败");
        }
    }

    @Test
    public void getCountSexTest(){
        int count = userService.countSex("男");
        System.out.println(count);
    }

    @Test
    public void getFindByAllUserPage(){
        int pageNum = 2;
        int pageSize = 3;
        int page = (pageNum-1)*pageSize;
        List<User> userList = userService.UserPage(page,pageSize);
        userList.forEach(user -> System.out.println(user));
    }

    @Test
    public void getFindByAllUserPage2(){
        PageInfo<User> pageInfo = userService.UserPage2(2,3);
        List<User> userList = pageInfo.getList();
        userList.forEach(user -> System.out.println(user));
    }

//    @Resource
//    private UserService userService;

//    @Test
//    public void getFindByAllTest(){
//        List<User> userList = userService.findByAll();
//        userList.forEach(user -> System.out.println(user.toString()));
//    }

//    @Test
//    public void save(){
//
//    }
//
//
//    @Test
//    public int countBySex(){
//
//    }
//    分页
    @Test
    public void getfindByAllUserPage(){
        PageInfo<User> pageInfo = userService.findByAllUserPage(1,2);
        List<User> userList = pageInfo.getList();
        userList.forEach(user -> System.out.println(user.toString()));
    }

}
