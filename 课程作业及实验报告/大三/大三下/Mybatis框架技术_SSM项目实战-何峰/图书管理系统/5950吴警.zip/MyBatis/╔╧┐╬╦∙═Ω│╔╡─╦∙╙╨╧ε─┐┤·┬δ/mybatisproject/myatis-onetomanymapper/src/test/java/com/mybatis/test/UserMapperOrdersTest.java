package com.mybatis.test;

import com.mybatis.mapper.UserMapperOrders;
import com.mybatis.pojo.OrderDetail;
import com.mybatis.pojo.Orders;
import com.mybatis.pojo.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class UserMapperOrdersTest {
    private SqlSessionFactory sqlSessionFactory;

    @Before
    public void setUp(){
        try {
            InputStream inputStream = Resources.getResourceAsStream("SqlMapConfig.xml");
            sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    @Test
    public void getOrdersByNumber(){
        SqlSession sqlSession =sqlSessionFactory.openSession();
        UserMapperOrders userMapperOrders = sqlSession.getMapper(UserMapperOrders.class);
        List<Orders> ordersList = userMapperOrders.getOrdersByNumber("1000010");
        ordersList.forEach(orders -> System.out.println(orders));
    }

    @Test
    public void findOrdersAndOrderDetail(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserMapperOrders userMapperOrders = sqlSession.getMapper(UserMapperOrders.class);
        List<Orders> ordersList = userMapperOrders.findOrdersAndOrderDetail("1000010");
        System.out.println("订单：" + ordersList.toString());
        for(Orders orders:ordersList){
            List<OrderDetail> orderDetailList = orders.getOrderDetails();
            orderDetailList.forEach(orderDetail -> System.out.println("订单明细:" + orderDetail));
        }
    }

    @Test
    public void findUserAndItemsResultMap(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserMapperOrders userMapperOrders = sqlSession.getMapper(UserMapperOrders.class);
        List<User> users = userMapperOrders.findUserAndItemsResultMap(1);
        //System.out.println(users);
        for(User user:users){
            System.out.println("订单信息");
            List<Orders> ordersList = user.getOrdersList();
            for(Orders orders:ordersList){
                System.out.println(orders);
                List<OrderDetail> orderDetailList = orders.getOrderDetails();
                System.out.println("订单明细");
                for(OrderDetail orderDetail:orderDetailList){
                    System.out.println(orderDetail.getItems());
                }
            }
        }
    }
}
