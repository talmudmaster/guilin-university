package com.mybatis.mapper;

import com.mybatis.pojo.Student;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface StudentMapper {

    //添加
    public int insertStudent(Student student);

    //查询所有
    public List<Student> findAll();

    //根据id查询
    public Student findStudentById(int id);

    //根据用户名和密码查询
    public Student findByUserNameAndPassword(@Param("username") String username, @Param("password") String password);

    //根据用户名模糊查询
    public List<Student> findByLikeUserName(String username);

    //修改
    public int updateStudent(Student student);

    //删除操作
    public int deleteStudentById(int id);

    //查询总记录数
    public int countByStudent();

    //分页查询
    public List<Student> getStudentLimit(Map<String,Integer> map);


    //分页查询
    public List<Student> getStudentByPageHelper();

}
