package dao;

import pojo.User;

import java.util.List;
import java.util.Map;

public interface UserDao2 {
    //根据id查询用户信息
    public User findUserById(int id);

    //根据用户名进行模糊查询
    public List<User> findUserByLikeName(String username);

    //添加用户
    public int insertUser(User user);

    //修改用户信息
    public int updateUser(User user);

    //根据用户名和性别查询用户信息
    public List<User> findUserByUserNameAndSex(User user);

    //根据用户名和性别查询用户信息
    public User findUserByUserNameAndSex2(Map map);

    //列表查询
    public List<User> findAll();

}
