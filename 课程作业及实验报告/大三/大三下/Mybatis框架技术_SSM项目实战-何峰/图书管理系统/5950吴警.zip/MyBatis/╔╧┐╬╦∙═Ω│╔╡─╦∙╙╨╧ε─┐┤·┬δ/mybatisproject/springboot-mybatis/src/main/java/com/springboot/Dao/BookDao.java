package com.springboot.Dao;

import com.springboot.pojo.Book;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface BookDao {
//    根据id查询
    public Book getfindBooksById(int id);
//    查询所有
    public List<Book> queryAll();
//    删除操作
    public boolean deleteById(int id);
//    添加操作
    public int insertBook(Book book);
//    修改操作
    public boolean updateBook(Book book);

//    public List<Book> findByAll();
















}
