package com.springboot.repository;

import com.springboot.pojo.EmpJPATest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

import javax.transaction.Transactional;
import java.util.List;

@Component
//继承JpaRepository<T,ID>
//T:要操作的实体类
//ID：实体类中对应的数据库表的主键类型（Integer）
public interface EmpRepository extends JpaRepository<EmpJPATest, Integer> {

//    登录操作（条件查询）
    EmpJPATest findByUsernameAndPassword(String username, String password);

//    根据用户名进行查询
//    EmpJPATest findByUsername(String username);

//    根据用户名进行模糊查询
//    模糊查询形式： A% %A %A%
    List<EmpJPATest> findByUsernameLike(String username);
//    List<EmpJPATest> findByUsernameStartingWith(String username);
//    List<EmpJPATest> findByUsernameEndWith(String username);

//    根据用户名进行模糊查询并按照添加时间进行排序
    List<EmpJPATest> findByUsernameContainingOrderByCreateTimeDesc(String username);

//    根据性别进行统计操作
    int countBySex(String sex);

//    根据id查询
//    注意点：基于实体类的查询操作，类名一定要大写 使用别名，条件对应实体类中属性名
//    @Query 基于注解操作
//    value：对应的语句（HPQL/SQL）
//    nativeQuery：boolean类型值，当值设置为true时，@Query支持SQL，默认值false，即只能编写JPQL语句
    @Query(value = "select emp from EmpJPATest emp where emp.id=?1 and emp.username=?2") //JPQL语句
    public EmpJPATest findByEmpId(int id,String username);

    @Query(value = "select emp from EmpJPATest emp where emp.username=:username and emp.password=:pwd") //JPQL语句
//    @Query(value = "select * from emp where emp.username=?1 and emp.password=?2", nativeQuery = true)
    public EmpJPATest findByUsernameAndPwd(@Param("username") String username, @Param("pwd") String pwd);

//    修改操作
    @Modifying //告诉Spring Data JPA这是一个update或delete操作
    @Transactional //事务提交，在进行写（修改、删除）操作时，必须要进行事务提交
//    @Query(value = "update emp set e.username =?1 where e.id =?2",nativeQuery = true)
    @Query(value = "update EmpJPATest e set e.username =?1 where e.id =?2")
    public int updateEmpJPATestById(String username,int id);

//    删除操作
    @Modifying //告诉Spring Data JPA这是一个update或delete操作
    @Transactional //事务提交，在进行写（修改、删除）操作时，必须要进行事务提交
//    注意：如果JPQL语句没有定义别名，则直接使用属性，如果定义别名则需要通过别名.属性 的方式进行条件处理
//    @Query(value = "delete from emp where e.id=?1",nativeQuery = true)
//    @Query(value = "delete from EmpJPATest e where e.id=?1")
    @Query(value = "delete from EmpJPATest where id=?1")
    public int deleteEmpJPATestById(int id);
    
}
