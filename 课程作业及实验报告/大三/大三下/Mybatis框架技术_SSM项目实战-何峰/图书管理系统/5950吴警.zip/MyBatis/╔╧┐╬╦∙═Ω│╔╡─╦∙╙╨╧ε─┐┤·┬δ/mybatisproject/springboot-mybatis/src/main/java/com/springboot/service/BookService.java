package com.springboot.service;

import com.springboot.pojo.Book;
import com.springboot.pojo.User;

import java.util.List;

public interface BookService {
    public Book findById(int id);

    public List<Book> findAll();

    public int save(Book book);

    public boolean deleteById(int id);

    public boolean updateById(Book book);


//    List<Book> findAllBook();

}
