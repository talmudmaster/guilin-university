package com.springboot.service;

import com.github.pagehelper.PageInfo;
import com.springboot.pojo.User;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;


public interface UserService {
    List<User> findAllUser();

    boolean addUser(User user);

    boolean save(User user);

//    boolean updateUser(User user);

//    boolean deleteUser(User user);

    User userLogin(String username,String address);

    int countSex(String sex);

    List<User> UserPage(int pageNum, int pageSize);

    PageInfo<User> UserPage2(int pageNum, int pageSize);

    //    修改
    boolean updateUser(User user);

    //    删除
    boolean deleteUser(int id);

    //    登录（用户名，地址）
    void findByUsernameAndPassword(String username, String address);

    //    根据sex统计查询
    int countBySex(String sex);

    //    分页
    PageInfo<User> findByAllUserPage(int pageNum, int pageSize);


}
