package com.springboot.Dao;

import com.springboot.pojo.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

//@Mapper将UserDao交给Spring容器进行管理

@Mapper
public interface UserDao {

    public User findById(int id);

    List<User> findByAll();

    boolean save(User user);

    User login(@Param("username") String username, @Param("address") String address);

    int count(String sex);

    List<User> findByAllUserPage(@Param("pageNum") int pageNum, @Param("pageSize") int pageSize);
    List<User> findByAllUserPage2(@Param("pageNum") int pageNum, @Param("pageSize") int pageSize);

//    修改
    boolean updateById(User user);

//    删除
    boolean deleteById(int id);

//    登录（用户名，地址）
    User findByUser(@Param("username") String username, @Param("address") String address);

//    根据sex统计查询
    int countSex(String sex);

//    分页
//    PageInfo<User> findByAllUserPage(int pageNum,int pageSize);

}
