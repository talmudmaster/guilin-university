package com.mybatis.pojo;

import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Orders {
    private int id;

    private int user_id;

    //订单号
    private String number;

    //下单时间
    private String createTime;

    //备注
    private String note;

    //用户信息
    private User user;

    //订单明细
    private List<OrderDetail> orderDetails;
}
