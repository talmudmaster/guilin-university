package com.springboot;

import com.springboot.pojo.EmpJPATest;
import com.springboot.repository.EmpRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import javax.annotation.Resource;
import javax.sql.DataSource;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

@SpringBootTest
class SpringbootSpringdatajpaApplicationTests {

    @Resource
    DataSource dataSource;

    @Autowired
    private EmpRepository empRepository;

    @Test
    public void getDataSourceTest() throws SQLException {
        System.out.println("获取连接对象："+dataSource.getClass());
        System.out.println("获取connection："+dataSource.getConnection());
    }

    @Test
    public void getSaveTest(){
        for (int i = 2; i <= 50; i++) {
            EmpJPATest empJPATest = new EmpJPATest();
            empJPATest.setUsername("admin" + i);
            empJPATest.setPassword("123" + i);
            empJPATest.setDept("研发"+ i + "部");
            empJPATest.setAge(28 + 1);
            empJPATest.setCreateTime(new Date());
            empJPATest.setPhone("18771983558");
            empRepository.save(empJPATest);
        }
    }

    @Test
    public void getFindById(){
        System.out.println(empRepository.findById(1));
    }

    //列表查询
    //排序查询：倒序【DESC】升序【ASC】

    @Test
    public void getFindByAll(){
        List<EmpJPATest> empJPATestList = empRepository.findAll();
        empJPATestList.forEach(empJPATest -> System.out.println(empJPATest));
    }

    @Test
    public void getFindSortByAll(){
        List<EmpJPATest> empJPATestList = empRepository.findAll(Sort.by(Sort.Direction.DESC,"id"));
        empJPATestList.forEach(empJPATest -> System.out.println(empJPATest));
    }

    //分页查询
    @Test
    public void getFindAllByPage(){
        Pageable pageable = PageRequest.of(0,5,Sort.by(Sort.Direction.DESC,"id"));
        Page<EmpJPATest> page = empRepository.findAll(pageable);
        //总记录数
        long totalElement = page.getTotalElements();
        //总页数
        int totalPages = page.getTotalPages();
        List<EmpJPATest> empJPATestList = page.getContent();
        empJPATestList.forEach(empJPATest -> System.out.println(empJPATest));
        System.out.println("总记录数："+totalElement);
        System.out.println("总页数："+totalPages);
    }

    @Test
    public void getUpdateById(){
        EmpJPATest empJPATest = empRepository.findById(3).orElse(null);
        empJPATest.setUsername("admin");
        empJPATest.setPassword("123456");
        empJPATest.setDept("研发3部");
        empJPATest.setAge(32);
        empJPATest.setCreateTime(new Date());
        empJPATest.setPhone("18771989067");
        empRepository.save(empJPATest);
    }

    //删除操作
    @Test
    public void deleteById(){
        empRepository.deleteById(51);
    }

//    修改操作
//    思路：要修改某条记录，首先必须要先查询出要修改的记录   findById方法
//    查询出对应的实例之后，修改实例的属性值
//    调用save()方法完成修改操作
    @Test
    public void getupdateTest(){
//        EmpJPATest empJPATest = new EmpJPATest();
//        empJPATest.setUserame("桂林学院");
//        empJPATest.setPassword("520");
//        empJPATest.setId(50);
//        empJPATest.setPhone("18771983558");
//        empJPATest.setSex("男");
//        empRepository.save(empJPATest);
        EmpJPATest empJPATest = empRepository.findById(49).get();
        empJPATest.setUsername("数字工厂");
        empRepository.save(empJPATest);
    }

//    登录操作（条件查询）
    @Test
    public void getFindByUsernameAndPassword(){
        EmpJPATest empJPATest = empRepository.findByUsernameAndPassword("数字工厂","12350");
        System.out.println(empJPATest.toString());
    }

//    @Test
//    public void getFindByUsername(){
//        EmpJPATest empJPATest = empRepository.findByUsername("admin");
//        System.out.println(empJPATest.toString());
//    }

//    根据用户名进行模糊查询
    @Test
    public void getFindByUsernameLike(){
        List<EmpJPATest> empJPATestList = empRepository.findByUsernameLike("%a%");
        empJPATestList.forEach(empJPATest -> System.out.println(empJPATest.toString()));
    }

    @Test
    public void getFindByUsernameContainingOrderByCreateTimeDesc(){
        List<EmpJPATest> empJPATestList = empRepository.findByUsernameContainingOrderByCreateTimeDesc("张");
        empJPATestList.forEach(empJPATest -> System.out.println(empJPATest.toString()));
    }

//    根据性别进行统计操作
    @Test
    public void getCountBySex(){
        int count = empRepository.countBySex("女");
        System.out.println("查询数："+count);
    }

//    根据id查询
    @Test
    public void getFindByEmpId(){
        EmpJPATest empJPATest = empRepository.findByEmpId(1,"admin2");
        System.out.println(empJPATest.toString());
    }

    @Test
    public void getFindByUsernameAndPwd(){
        EmpJPATest empJPATest = empRepository.findByUsernameAndPwd("张三疯","12315");
        System.out.println(empJPATest.toString());
    }

    @Test
    public void getDeleteEmpById(){
        int result = empRepository.deleteEmpJPATestById(48);
    }

    @Test
    public void getUpdateEmpJPATestById(){
        int result = empRepository.updateEmpJPATestById("李四",22);
    }

}
