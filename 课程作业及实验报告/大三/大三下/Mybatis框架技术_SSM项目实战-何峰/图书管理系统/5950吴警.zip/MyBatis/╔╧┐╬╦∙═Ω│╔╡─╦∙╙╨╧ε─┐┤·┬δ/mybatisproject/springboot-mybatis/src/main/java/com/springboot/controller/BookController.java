package com.springboot.controller;

import com.springboot.pojo.Book;
import com.springboot.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class BookController {
    @Autowired
    private BookService bookService;

//    列表查询
    @RequestMapping(value = "/findBookAll", method = RequestMethod.GET)
    public String findBookAll(Model model){
        List<Book> bookList = bookService.findAll();
        model.addAttribute("booklist",bookList);
        return "showBook";
    }

//    删除操作
    @RequestMapping(value = "/deleteById", method = RequestMethod.GET)
//    RESULTful
//    @GetMapping(value = "/deleteById")
    private String deleteById(String id){
        System.out.println("=====>id"+id);
        boolean result = bookService.deleteById(Integer.parseInt(id));
        if(result){
//            业务场景：从A请求跳转到B请求，实现方式
//            1.重定向（redirect）   不传参     两次请求
//            2.转发（forward）      传参      一次请求
            return "forward:/findBookAll";

//            return "redirect:/findBookAll?id=1100";
        }else{
            return null;
        }
    }

//    修改
//    1.先查询出要修改的记录=====>findById(int id)
//    2.修改，保存操作=====>updateBook()
//    findById?id=148
    @GetMapping(value = "/findById")
    public String findBookById(int id,Model model){
        Book book = bookService.findById(id);
        model.addAttribute("book",book);
        return "updateBook";
//        book.setName("SSM实训入门到高级");
//        boolean result = bookService.updateById(book);
//        System.out.println(result);
//        return "forward:/findBookAll";
    }

//    修改保存操作
    @PostMapping(value = "updateAndSaveBook")
    public String updateBook(Book book){
        System.out.println("=====>book"+book);
//        boolean result = bookService.updateById(book);
        if(book.getId() != 0){
            boolean result = bookService.updateById(book);

            if(result){
                return "redirect:/findBookAll";
            }else {
                return "updateBook";
            }
        }else{
            int count = bookService.save(book);
            if(count>0){
                return "redirect:/findBookAll";
            }else{
                return "updateBook";
            }
        }
    }

//    添加请求操作
    @GetMapping(value = "/addUrl")
    public String addUrl(){
        return "addBook";
    }
}
