package com.mybatis.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Items {
    private int id;

    private String name;

    private float price;

    private String detail;

    private String pic;

    private String createTime;
}
