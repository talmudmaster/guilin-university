package com.mybatis.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Book {
    private int id;
    //图书名称
    private String name;
    //作者
    private String author;
    //图书单价
    private double price;
    //图书销量
    private int sales;
    //库存
    private int stock;
    //封面路径
    private String imgPath;
    //出版日期
    private String pressDate;
    //出版社
    private String press;
}
