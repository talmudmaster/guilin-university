package com.mybatis.pojo;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrderDetail {
    private int id;

    private int ordersId;

    private int itemsId;

    private int itemsNum;

    //明细对应的商品信息
    private Items items;
}
