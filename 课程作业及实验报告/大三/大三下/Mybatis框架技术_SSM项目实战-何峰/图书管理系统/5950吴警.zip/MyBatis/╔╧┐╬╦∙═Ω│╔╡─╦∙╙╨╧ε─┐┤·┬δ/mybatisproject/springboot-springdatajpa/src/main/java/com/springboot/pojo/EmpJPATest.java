package com.springboot.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

/**
 * 实体类映射成数据库表
 * */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity  //指定当前类是实体类
@Table(name = "emp") //指定的数据库表名
public class EmpJPATest {
    /**
     * GenerationType.AUTO:由程序自动选择一种主键生成策略（mysql）
     * GenerationType.IDENTITY：自增，底层数据库必须支持自增（mysql）
     * GenerationType.SEQUENCE：序列，底层数据库必须支持序列（Oracle）
     * GenerationType.TABLE：JPA提供的一种策略，通过一张临时表来完成主键的自增操作，使用较少
     * */
    @Id //指定当前字段为数据库表主键
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    /**
     * 场景：订单号作为主键，String类型？？？
     * @Id
     * @GenericGenerator(name = "orderIdGenerator",strategy = "uuid")
     * @GeneratedValue(generator = "orderIdGenerator",strategy = "assigned") //通用方式
     * private String orderId;
     * */
    /**
     * Column():用于对属性（数据库表字段）的设置
     *  name：指定数据库表字段名
     *  unique：是否唯一，默认值：false
     *  nullable：是否为空，默认值：true
     *  length：长度，默认汉字：255
     * */

    @Column(name = "username",unique = true, nullable = false, length = 20)
    private String username;

    @Column(nullable = false, length = 40)
    private String password;

    @Column(length = 4)
    private int age;

    @Temporal(TemporalType.DATE) //yyyy-mm-dd 类型日期
    private Date createTime;

    private String dept;

    @Column(nullable = false, length = 11)
    private String phone;

    private String sex;
}
