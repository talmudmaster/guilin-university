package com.springboot;

//import com.springboot.mapper.UserMapper;
import com.springboot.pojo.User;
import com.springboot.pojo.YamlBean;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.aspectj.lang.annotation.Before;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import javax.annotation.Resource;
import javax.sql.DataSource;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;

@SpringBootTest
class SpringbootMybatisApplicationTests {

    @Resource
    DataSource dataSource;

//    @Autowired
//    private EmpRepository empRepository;

    @Autowired
    //@Resource
    private YamlBean yamlBean;

    @Resource
//    private DataSource dataSource;

    @Test
    public void yamlBeanTest() {
        System.out.println(yamlBean.getName());
        System.out.println(yamlBean.getMessage());
        System.out.println(yamlBean.getUser());
        System.out.println("=========");
        System.out.println(yamlBean.toString());
    }

    @Test
    public void DataSourceTest() throws SQLException {
        System.out.println("连接类型：" + dataSource.getClass());
        Connection connection = dataSource.getConnection();
        System.out.println("connection连接对象：" + connection);
    }

}
