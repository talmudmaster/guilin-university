package com.mybatis.mapper;

import com.mybatis.pojo.Orders;
import com.mybatis.pojo.User;

import java.util.List;

public interface UserMapperOrders {
    //通过订单号查询订单及用户信息(1:1)
    public List<Orders> getOrdersByNumber(String number);

    //通过订单号查询订单明细（1:n）
    public List<Orders> findOrdersAndOrderDetail(String number);

    //查询用户购买的商品信息
    public List<User> findUserAndItemsResultMap(int id);
}
