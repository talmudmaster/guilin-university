package com.mybatis.test;

import dao.UserDao2;
import dao.impl.UserDaoImpl;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Before;
import org.junit.Test;
import pojo.User;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MyBatisDaoTest {

    private SqlSessionFactory sqlSessionFactory;

    //创建SqlSeFactory会话工厂
    @Before //在执行测试之前执行的方法
    public void setUp(){
        try {
            //获取配置流对象
            InputStream inputStream =  Resources.getResourceAsStream("SqlMapConfig.xml");
            sqlSessionFactory = new SqlSessionFactoryBuilder().build( inputStream );
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    @Test
    public void findUserByIdTest(){
        UserDao2 userDao2 = new UserDaoImpl( sqlSessionFactory );
        User user=userDao2.findUserById(1);
        System.out.println(user.toString());
    }

    @Test
    public void findUserByLikeNameTest(){
        UserDao2 userDao2 = new UserDaoImpl( sqlSessionFactory );
        List<User> userList = userDao2.findUserByLikeName( "范" );
        for (User user:userList){
            System.out.println(user.toString());
        }
    }

    @Test
    public void insertUser(){
        UserDao2 userDao2 = new UserDaoImpl( sqlSessionFactory );
        int user = userDao2.insertUser(new User( 6,"范傻傻","女","1982-09-08" ));
        System.out.println(user);
    }

    @Test
    public void updateUser(){
        UserDao2 userDao2 = new UserDaoImpl( sqlSessionFactory );
        int user = userDao2.updateUser(new User( 4,"范呆头","女","2003-09-08" ));
        System.out.println(user);
    }

    @Test
    public void findUserByUsernameAndSex(){
        UserDao2 userDao2 = new UserDaoImpl(sqlSessionFactory);
        User result = new User();
        result.setUsername("范呆头");
        result.setSex("女");
        List<User> userList = userDao2.findUserByUserNameAndSex(result);
        for(User user:userList){
            System.out.println(user);
        }
    }

    @Test
    public void findUserByUsernameAndSex2(){
        UserDao2 userDao2 = new UserDaoImpl(sqlSessionFactory);
        Map<String,Object> map = new HashMap<String, Object>();
        map.put( "username","范呆头" );
        map.put( "sex","女" );
        User user = userDao2.findUserByUserNameAndSex2(map);
        System.out.println(user);
    }

    @Test
    public void findAll(){
        UserDao2 userDao2 = new UserDaoImpl( sqlSessionFactory );
        List<User> userList = userDao2.findAll();
        for (User user:userList) {
            System.out.println( user );
        }
    }
}
