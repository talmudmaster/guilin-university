package com.springboot.service.impl;

import com.springboot.Dao.BookDao;
import com.springboot.Dao.UserDao;
import com.springboot.pojo.Book;
import com.springboot.service.BookService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class BookServiceImpl implements BookService {

    @Resource
    private BookDao bookDao;

    @Override
    public Book findById(int id) {
        return bookDao.getfindBooksById(id);
    }

    @Override
    public List<Book> findAll() {
        return bookDao.queryAll();
    }

    @Override
    public int save(Book book) {
        return bookDao.insertBook(book);
    }

    @Override
    public boolean deleteById(int id) {
        return bookDao.deleteById(id);
    }

    @Override
    public boolean updateById(Book book) { return bookDao.updateBook(book); }


//    @Override
//    public List<Book> findAllBook() {
//        return bookDao.findByAll();
//    }

}
