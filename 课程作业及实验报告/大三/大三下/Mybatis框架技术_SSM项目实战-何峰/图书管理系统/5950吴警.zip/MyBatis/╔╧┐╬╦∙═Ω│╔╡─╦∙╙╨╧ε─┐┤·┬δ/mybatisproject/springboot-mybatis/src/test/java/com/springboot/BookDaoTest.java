package com.springboot;

import com.springboot.pojo.Book;
import com.springboot.service.BookService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
public class BookDaoTest {
    @Autowired
    private BookService bookService;

    @Test
    public void getFindById(){
        Book book = bookService.findById(5);
        System.out.println(book);
    }

    @Test
    public void getFindAll(){
        List<Book> bookList = bookService.findAll();
        bookList.forEach(book -> System.out.println(book));
    }

//    @Test
//    public void getDeleteById(){
//        boolean book = bookService.deleteById(4);
//    }


//    @Test
//    public void getFindByAllBookTest(){
//        List<Book> bookList = bookService.findAllBook();
//        bookList.forEach(book -> System.out.println(book));
//    }
}
