package com.springboot.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.xml.ws.RequestWrapper;
//@RestController = @Controller + @ResponseBody
//@ResponseBody : 表示响应结果的类型，返回的是Json格式的数据，视图解析器就无法解析为html模板页
//如果要返回视图页面，就需要使用@Controller
//@RestController //表示是控制层（控制器）
@Controller
@RequestMapping("/user")
public class UserController {
//    restful
//    get与post区别
//    1.post比get更安全
//    2.get请求中请求参数会在URL中显示，post不会
//    3.get请求有长度限制，post没有
//    4.get请求url地址会跳转，post请求url地址不变
//    @RequestMapping用于URL请求与控制器中方法的映射
//    请求URL:http://127.0.0.0(localhost):8080/index
    @RequestMapping(value = "/hello", method = RequestMethod.GET)
    @ResponseBody
    public String helloWorld(){
        System.out.println("===控制器视图映射匹配===");
        return "hello，开始学习视图层的控制操作！！！"; //返回JSON格式数据
    }
//    controller传递参数到视图页面的方式：Model、ModelAndView、request、session（全局）
//    请求URL:http://127.0.0.0(localhost):8080/user/index
    @RequestMapping(value = "/index",method = RequestMethod.GET)
    public String index(Model model,HttpServletRequest request){
        HttpSession session = request.getSession();
        session.setAttribute("sessionMsg","session对象传值操作");
        request.setAttribute("reqMsg","request对象传值操作");
        model.addAttribute("msg","Model对象传值操作");
        return "index"; //index.html ==> 视图名称
    }

//    通过ModelAndView对象传递值
//    请求URL:http://127.0.0.0(localhost):8080/user/mvIndex
    @RequestMapping(value = "mvIndex", method = RequestMethod.GET)
    public ModelAndView modelAndViewIndex(){
        ModelAndView mv = new ModelAndView();
        mv.addObject("mvMsg","ModelAndView对象传值操作");
        mv.setViewName("index");
        return mv;
    }


}
