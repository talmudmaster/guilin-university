package com.mybatis.mapper;

import com.mybatis.pojo.Book;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface BookMapper {
    //添加
    public int insertBook(Book book);

    //根据id查询
    public Book findBookById(int id);

    public List<Book> selectBookByNameIf(String name);

    public List<Book> selectBookByChoose(Map map);

    public boolean updateBookBySet(Map map);

    //批处理传数据，传Map
    public List<Book> findBookListIn(List list);

    public List<Book> findBookListInArray(int[] ids);

    //根据批量条件查询
    //public List<Book> findBookListInMap(@Param("ids") int[] ids, @Param("author") String author);
    public List<Book> findBookListInMap(Map map);

    //批量删除
    public boolean deleteBookInArray(int[] dis);

    //模糊查询
    public List<Book> findBookLikeInArrayBind(String name);

    //查询价值高于90的书
    public List<Book> findBookByPriceGt90(double price);

    //查询价值为50-90的书
    public List<Book> findBookByPriceGt50Lt90(@Param("minPrice") double minPrice,@Param("maxPrice") double maxPrice);
    public List<Book> findBookByPriceGt50Lt90(Map map);
}
