import cn.hutool.core.util.ObjectUtil;
import com.mybatis.mapper.BookMapper;
import com.mybatis.pojo.Book;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Array;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BookMapperTest {
    private SqlSessionFactory sqlSessionFactory;

    @Before
    public void setUp(){
        try {
            InputStream inputStream = Resources.getResourceAsStream("SqlMapConfig.xml");
            sqlSessionFactory = new SqlSessionFactoryBuilder().build( inputStream );
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void insertBookTest(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        BookMapper bookMapper = sqlSession.getMapper(BookMapper.class);
        Book book = new Book();
        book.setName("李四成长史");
        book.setAuthor("李四");
        book.setPrice(23.99);
        book.setSales(923);
        book.setStock(1234);
        book.setImgPath("root/book/demo.jpg");
        book.setPressDate("2003-06-18");
        book.setPress("湖南长沙");
        int result = bookMapper.insertBook(book);
        System.out.println(result);
        sqlSession.commit();
    }

    @Test
    public void findBookById(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        BookMapper bookMapper = sqlSession.getMapper(BookMapper.class);
        Book book = bookMapper.findBookById(1);
        if(!ObjectUtil.hasEmpty(book)){
            System.out.println(book);
        }else{
            System.out.println("没有查询到相关的记录！！！");
        }
    }

    @Test
    public void selectBookByNameIfTest(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        BookMapper bookMapper = sqlSession.getMapper(BookMapper.class);
        List<Book> bookList = bookMapper.selectBookByNameIf("软件需求工程");
        bookList.forEach(book -> System.out.println(book));
    }

    @Test
    public void selectBookByChooseTest(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        BookMapper bookMapper = sqlSession.getMapper(BookMapper.class);
        Map<String,Object> map = new HashMap<>();
        map.put("name","软件工程");
        map.put("price",23.99);
        List<Book> bookList = bookMapper.selectBookByChoose(map);
        bookList.forEach(book -> System.out.println(book));
    }

    @Test
    public void updateBookBySetTest(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        BookMapper bookMapper = sqlSession.getMapper(BookMapper.class);
        Map<String,Object> map = new HashMap<>();
        map.put("id",7);
        map.put("name","软件工程");
        map.put("price",27.99);
        map.put("pressDate","2000-11-08");
        boolean book = bookMapper.updateBookBySet(map);
        System.out.println(book);
        sqlSession.commit();
    }

    @Test
    public void findBookListIn(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        BookMapper bookMapper = sqlSession.getMapper(BookMapper.class);
        List<Integer> list = Arrays.asList(11,13,15,17,18,19);
        List<Book> books =  bookMapper.findBookListIn(list);
        books.forEach(book -> System.out.println(book));
    }

    @Test
    public void findBookListInArray(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        BookMapper bookMapper = sqlSession.getMapper(BookMapper.class);
        int ids[] = {11,13,14,15,17,18,19};
        List<Book> books =  bookMapper.findBookListInArray(ids);
        books.forEach(book -> System.out.println(book));
    }

    @Test
    public void findBookListInMap(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        BookMapper bookMapper = sqlSession.getMapper(BookMapper.class);
        int ids[] = {1,2,3};
        Map<String,Object> map = new HashMap<>();
        map.put("ids",ids);
        map.put("author","范呆呆");
        List<Book> books =  bookMapper.findBookListInMap(map);
        books.forEach(book -> System.out.println(book));
    }

    @Test
    public void deleteBookInArray(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        BookMapper bookMapper = sqlSession.getMapper(BookMapper.class);
        int dis[] = {11,13};
        boolean book = bookMapper.deleteBookInArray(dis);
        System.out.println(book);
        sqlSession.commit();
    }

    @Test
    public void findBookLikeInArrayBind(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        BookMapper bookMapper = sqlSession.getMapper(BookMapper.class);
        List<Book> bookList = bookMapper.findBookLikeInArrayBind("范");
        bookList.forEach(book -> System.out.println(book));
    }

    @Test
    public void findBookByPriceGt90(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        BookMapper bookMapper = sqlSession.getMapper(BookMapper.class);
        List<Book> bookList = bookMapper.findBookByPriceGt90(30);
        bookList.forEach(book -> System.out.println(book));
    }

    @Test
    public void findBookByPriceGt50lt90(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        BookMapper bookMapper = sqlSession.getMapper(BookMapper.class);
        //方式一
        List<Book> bookList = bookMapper.findBookByPriceGt50Lt90(30,90);
        bookList.forEach(book -> System.out.println(book));
        //方式二
        Map<String,Object> map = new HashMap<>();
        map.put("minPrice",30);
        map.put("maxPrice",90);
        List<Book> bookList2 = bookMapper.findBookByPriceGt50Lt90(map);
        //bookList2.forEach(book -> System.out.println(book));
    }
}
