package dao.impl;

import dao.UserDao2;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import pojo.User;

import java.util.List;
import java.util.Map;


/**
 * 练习：实现接口类
 * */
public class UserDaoImpl implements UserDao2 {

    private SqlSessionFactory sqlSessionFactory;

    //需要向dao实现类中注入SessionFactory，由于没有和Spring整合，这里通过构造函数注入
    public UserDaoImpl(SqlSessionFactory sqlSessionFactory){
        this.sqlSessionFactory = sqlSessionFactory;
    }

    public User findUserById(int id) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        User user = sqlSession.selectOne("myBatisTest.findUserById",id);
        return user;
    }

    public List<User> findUserByLikeName(String username) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        List<User> userList = sqlSession.selectList( "myBatisTest.findUserByLikeName",username );
        return userList;
    }

    public int insertUser(User user) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        int user1 = sqlSession.insert( "myBatisTest.insertUser",user);
        sqlSession.commit();
        return user1;
    }

    public int updateUser(User user) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        int user2 = sqlSession.update( "myBatisTest.updateUser",user);
        sqlSession.commit();
        return user2;
    }


    /**
     * 原始DaO操作
     * 对于多条件查询操作，可以使用一下两种方式
     *          1、使用对象构造查询条件
     *          2、使用Map集合构造查询条件Map<k,v>
     * */

    public List<User> findUserByUserNameAndSex(User user) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        List<User> result = sqlSession.selectList("myBatisTest.findUserByUserNameAndSex",user);
        return result;
    }

    public User findUserByUserNameAndSex2(Map map) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        User result = sqlSession.selectOne("myBatisTest.findUserByUserNameAndSex2",map);
        return result;
    }


    public List<User> findAll(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        List<User> userList = sqlSession.selectList( "myBatisTest.findAll");
        return userList;
    }
}
