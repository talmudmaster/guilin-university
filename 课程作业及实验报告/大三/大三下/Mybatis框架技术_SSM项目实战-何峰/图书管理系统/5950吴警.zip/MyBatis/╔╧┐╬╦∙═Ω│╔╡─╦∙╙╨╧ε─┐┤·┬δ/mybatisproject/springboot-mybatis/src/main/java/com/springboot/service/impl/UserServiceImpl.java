package com.springboot.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.springboot.Dao.UserDao;
import com.springboot.pojo.User;
import com.springboot.service.UserService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {
//    @Autowired
    @Resource
    private UserDao userDao;

    @Override
    public List<User> findAllUser() {
        return userDao.findByAll();
    }

//    @Override
//    public boolean addUser(User user) {
//        return userDao.save(user);
//    }

    @Override
    public boolean save(User user) {
        return userDao.save(user);
    }

//    @Override
//    public boolean updateUser(User user) {
//        return userDao.updateById("1","2","3","4","5");
//    }

    @Override
    public boolean deleteUser(int id) {
        return userDao.deleteById(1);
    }

    @Override
    public User userLogin(String username , String address) {
        return userDao.login(username,address);
    }

    @Override
    public int countSex(String sex) {
        return userDao.count(sex);
    }

    @Override
    public List<User> UserPage(int pageNum, int pageSize) {
        return userDao.findByAllUserPage(pageNum,pageSize);
    }

    @Override
    public PageInfo<User> UserPage2(int pageNum , int pageSize) {
        PageHelper.startPage(pageNum,pageSize);
        List<User> userList = userDao.findByAll();
        PageInfo<User> pageInfo = new PageInfo<>(userList);
        return pageInfo;
    }

    @Override
    public boolean updateUser(User user) {
        return false;
    }


    @Override
    public void findByUsernameAndPassword(String username, String address) {

    }


    @Override
    public int countBySex(String sex) {
        return 0;
    }

    @Override
    public PageInfo<User> findByAllUserPage(int pageNum, int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<User> userList = userDao.findByAll();
        PageInfo<User> pageInfo = new PageInfo<>(userList);
        return pageInfo;
    }

    @Override
    public boolean addUser(User user){
        return userDao.save(user);
    }
}
