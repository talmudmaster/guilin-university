package com.mybatis.dao;

import com.mybatis.pojo.Administrator;
import com.mybatis.pojo.Books;
import com.mybatis.pojo.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface AdministratorMapper {
//    登录查询
    public Administrator logIn(@Param("account")String account, @Param("password")String password);

//  查看图书信息
    public List<Books> findAllBooks();
    public Books findBooksByName(String bookname);
//    添加图书信息
    public boolean addBook(Books books);
//    修改图书信息
    public boolean updateBook(Books books);
//    删除图书信息
    public boolean deleteBook(String name);
//    书名模糊查询
    public List<Books> findBookNameLike(String name);
//    查看所有用户
    public List<User> findAllUser();
//    用户名模糊查询
    public List<User> findUserNameLike(String name);
//    注销用户
    public boolean deleteUser(String name);
}
