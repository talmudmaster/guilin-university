package com.mybatis.Impl;

import com.mybatis.dao.AdministratorMapper;
import com.mybatis.pojo.Administrator;
import com.mybatis.pojo.Books;
import com.mybatis.pojo.User;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;

public class AdministratorImpl implements AdministratorMapper {
    private SqlSessionFactory sqlSessionFactory;

    public AdministratorImpl(SqlSessionFactory sqlSessionFactory){
        this.sqlSessionFactory = sqlSessionFactory;
    }

    @Override
    public Administrator logIn(String account, String password) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        AdministratorMapper administratorMapper = sqlSession.getMapper(AdministratorMapper.class);
        Administrator administrator = administratorMapper.logIn(account,password);
        return administrator;
    }
    //增加图书
    @Override
    public boolean addBook(Books books) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        AdministratorMapper administratorMapper = sqlSession.getMapper(AdministratorMapper.class);
        administratorMapper.addBook(books);
        sqlSession.commit();
        sqlSession.close();
        return true;
    }
    //查看所有图书
    @Override
    public List<Books> findAllBooks(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        AdministratorMapper administratorMapper = sqlSession.getMapper(AdministratorMapper.class);
        List<Books> books = administratorMapper.findAllBooks();
        sqlSession.close();
        return books;
    }

    @Override
    public Books findBooksByName(String bookname) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        AdministratorMapper administratorMapper = sqlSession.getMapper(AdministratorMapper.class);
        return administratorMapper.findBooksByName(bookname);
    }

    //更新图书信息
    @Override
    public boolean updateBook(Books books){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        AdministratorMapper administratorMapper = sqlSession.getMapper(AdministratorMapper.class);
        administratorMapper.updateBook(books);
        sqlSession.commit();
        sqlSession.close();
        return true;
    }

    @Override
    public boolean deleteBook(String name) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        AdministratorMapper administratorMapper = sqlSession.getMapper(AdministratorMapper.class);
        administratorMapper.deleteBook(name);
        sqlSession.commit();
        sqlSession.close();
        return true;
    }

    //书名模糊查询
    @Override
    public List<Books> findBookNameLike(String name) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        AdministratorMapper administratorMapper = sqlSession.getMapper(AdministratorMapper.class);
        List<Books> booksList = administratorMapper.findBookNameLike(name);
        sqlSession.close();
        return booksList;
    }
    //查看所有用户
    @Override
    public List<User> findAllUser() {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        AdministratorMapper administratorMapper = sqlSession.getMapper(AdministratorMapper.class);
        List<User> users = administratorMapper.findAllUser();
        return users;
    }
    //用户模糊查询
    @Override
    public List<User> findUserNameLike(String name) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        AdministratorMapper administratorMapper = sqlSession.getMapper(AdministratorMapper.class);
        List<User> users = administratorMapper.findUserNameLike(name);
        return users;
    }
    //注销用户
    @Override
    public boolean deleteUser(String name) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        AdministratorMapper administratorMapper = sqlSession.getMapper(AdministratorMapper.class);
        boolean b = administratorMapper.deleteUser(name);
        sqlSession.commit();
        sqlSession.close();
        return true;
    }
}
