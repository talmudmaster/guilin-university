package com.mybatis.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class Administrator {
//    管理员编号
    private int id;
//    用户名
    private String account;
//    密码
    private String password;
//    注册时间
    private String createTime;

}
