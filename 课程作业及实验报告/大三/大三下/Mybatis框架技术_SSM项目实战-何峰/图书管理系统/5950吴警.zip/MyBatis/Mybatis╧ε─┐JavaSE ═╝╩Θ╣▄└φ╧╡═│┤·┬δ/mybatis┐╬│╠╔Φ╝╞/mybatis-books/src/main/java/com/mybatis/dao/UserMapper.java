package com.mybatis.dao;

import com.mybatis.pojo.Books;
import com.mybatis.pojo.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserMapper {
//    用户注册
    public boolean addUser(User user);
//    用户登录
    public User LogIn(@Param("username")String username, @Param("password")String password);
//    查询所有书籍
    public List<Books> findAllBooks();
//    修改密码
    public boolean updateUserPassword(@Param("username") String username,@Param("password") String password);
//    根据书名搜索
    public Books findBooksByName(String bookname);
//    查看个人注册信息
    public User findUserByName(String username);
//    修改个人信息
    public boolean updateUser(User user);
//    退出操作

//    A、借书、B、还书
}
