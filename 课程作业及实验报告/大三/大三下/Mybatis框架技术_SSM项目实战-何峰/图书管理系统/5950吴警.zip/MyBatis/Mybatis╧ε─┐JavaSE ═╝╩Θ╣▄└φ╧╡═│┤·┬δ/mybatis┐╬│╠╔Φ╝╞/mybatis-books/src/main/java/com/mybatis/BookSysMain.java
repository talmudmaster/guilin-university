package com.mybatis;

import com.mybatis.Impl.AdministratorImpl;
import com.mybatis.Impl.UserImpl;
import com.mybatis.dao.AdministratorMapper;
import com.mybatis.mybatis;
import com.mybatis.pojo.Administrator;
import com.mybatis.pojo.Books;
import com.mybatis.pojo.User;
import com.mysql.cj.jdbc.util.BaseBugReport;
import lombok.var;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class BookSysMain {

    public static void main(String[] args) {
        SqlSessionFactory factory = mybatis.setUp(); //调用会话工厂
        AdministratorImpl administratorImpl = new AdministratorImpl(factory); //引入管理员类里的需求方法
        UserImpl userImpl = new UserImpl(factory);
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("***************图书管理系统***************\n****************************************\n" +
                    "1.管理员登录 2.用户注册登录 3.退出系统\n****************************************\n" +
                    "请选择，请输入正确的选项！");
            String sel_lg_s = scanner.nextLine();
            //保证输入选择项符合规则，若输入错误选项则重新输入
            if(sel_lg_s.compareTo("1")<0||sel_lg_s.compareTo("3")>0){
                continue;
            }
            int sel_lg = Integer.parseInt(sel_lg_s);
            //管理员操作
            if (sel_lg == 1) {
                System.out.println("请输入管理员账号:");
                String ad_U = scanner.nextLine();
                System.out.println("请输入管理员密码：");
                String ad_P = scanner.nextLine();
                Administrator admin = administratorImpl.logIn(ad_U, ad_P);
                if (admin != null) {
                    System.out.println(admin);
                    System.out.println("管理员登录成功");
                    while (true) {
                        System.out.println("=================================\n1.查看图书 2.添加图书 3.修改图书 4.删除图书 5.书名模糊查询\n" +
                                " 6.查询所有用户 7.用户模糊查询 8.注销用户 9.退出操作 10.退出系统\n=================================\n" +
                                "请选择，请正确输入需要操作的选项！");
                        String aSelect_s = scanner.nextLine();
                        //保证输入选择项符合规则，若输入错误选项则重新输入
                        if(aSelect_s.compareTo("1")<0||aSelect_s.compareTo("9")>0){
                            continue;
                        }
                        int aSelect = Integer.parseInt(aSelect_s);  //输入选择
                        //========================查看所有图书=========================
                        if (aSelect == 1) {
                            List<Books> books = administratorImpl.findAllBooks();
                            System.out.println("\n");
                            books.forEach(b -> System.out.println(b));
                            System.out.println("还需要进行以下其他操作吗？");
                        }
                        //=========================添加图书=========================
                        if (aSelect == 2) {
                            Books books = new Books();
                            //输入书名
                            System.out.println("请输入书名：");
                            String bN = scanner.nextLine();
                            books.setBookName(bN);
                            //输入作者名
                            System.out.println("请输入作者名：");
                            String bAut = scanner.nextLine();
                            books.setAuthor(bAut);
                            //输入价格
                            System.out.println("请输入价格数：");
                            double bPri = Double.parseDouble(scanner.nextLine());
                            books.setPrice(bPri);
                            //输入日期
                            System.out.println("请按照yyyy-mm-dd格式输入出版日期的数字：");
                            String puDate = scanner.nextLine();
                            books.setPublishDate(puDate);
                            //输入出版社
                            System.out.println("请输入出版社：");
                            String pre = scanner.nextLine();
                            books.setPress(pre);
                            //输入图书类型
                            System.out.println("请输入图书类型：");
                            String bTy = scanner.nextLine();
                            books.setBookType(bTy);
                            //输入印刷次数
                            System.out.println("请输入印刷次数：");
                            int fre = Integer.parseInt(scanner.nextLine());
                            books.setFrequency(fre);
                            //输入上架时间
                            System.out.println("请按照yyyy-mm-dd格式输入上架日期的数字：");
                            String slDate = scanner.nextLine();
                            books.setShelfTime(slDate);

                            boolean add = administratorImpl.addBook(books);
                            if (add) {
                                System.out.println("\n添加成功,还需要进行以下其他操作吗？");
                            } else {
                                System.out.println("\n添加失败");
                            }
                        }

                        //==========================修改图书=========================
                        if (aSelect == 3) {
                            System.out.println("请输入要修改的图书的名称：");
                            String b_FN = scanner.nextLine();
                            Books books = administratorImpl.findBooksByName(b_FN);
                            if (books == null) {
                                System.out.println("没有这本书，请重新操作");
                            } else {
                                //图书名修改
                                System.out.println("请输入要修改的图书名，若不修改图书名请按Enter键进行下一步：");
                                String b_UpN = scanner.nextLine();
                                if (!b_UpN.isEmpty()) {
                                    books.setBookName(b_UpN);
                                }
                                //作者名修改
                                System.out.println("请输入要修改的作者名，若不修改作者名请按Enter键进行下一步：");
                                String b_UpA = scanner.nextLine();
                                if (!b_UpA.isEmpty()) {
                                    books.setAuthor(b_UpA);
                                }
                                //价格修改
                                System.out.println("请输入要修改的价格数，若不修改价格数请按Enter键进行下一步：");
                                String sPri = scanner.nextLine();
                                if (!sPri.isEmpty()) {
                                    double b_UpPri = Double.parseDouble(sPri);
                                    books.setPrice(b_UpPri);
                                }
                                //出版时间修改
                                System.out.println("请按照yyyy-mm-dd格式输入要修改的出版时间，若不修改出版时间可按Enter键进行下一步：");
                                String b_UpPuDt = scanner.nextLine();
                                if (!b_UpPuDt.isEmpty()) {
                                    books.setPublishDate(b_UpPuDt);
                                }
                                //出版社修改
                                System.out.println("请输入要修改的出版社，若不修改出版社可按Enter键进行下一步：");
                                String b_UpPre = scanner.nextLine();
                                if (!b_UpPre.isEmpty()) {
                                    books.setPress(b_UpPre);
                                }
                                //图书类型修改
                                System.out.println("请输入要修改的图书类型，若不修改图书类型可按Enter键进行下一步：");
                                String b_UpBTy = scanner.nextLine();
                                if (!b_UpBTy.isEmpty()) {
                                    books.setBookType(b_UpBTy);
                                }
                                //印刷次数修改
                                System.out.println("请输入要修改的印刷次数，若不修改印刷次数可按Enter键进行下一步：");
                                String iFre = scanner.nextLine();
                                if (!iFre.isEmpty()) {
                                    int b_UpFre = Integer.parseInt(iFre);
                                    books.setFrequency(b_UpFre);
                                }
                                //上架时间修改
                                System.out.println("请按照yyyy-mm-dd格式输入要修改的上架时间，若不修改上架时间可按Enter键进行下一步：");
                                String b_UpST = scanner.nextLine();
                                if (!b_UpST.isEmpty()) {
                                    books.setShelfTime(b_UpST);
                                }

                                boolean b = administratorImpl.updateBook(books);
                                if (b) {
                                    System.out.println("\n修改成功,还需要进行以下其他操作吗？");
                                } else {
                                    System.out.println("\n修改失败");
                                }
                            }
                        }
                        //==========================删除图书=========================
                        if (aSelect == 4) {
                            System.out.println("请输入要删除的图书名称");
                            String delBookName = scanner.nextLine();
                            boolean b = administratorImpl.deleteBook(delBookName);
                            if (b) {
                                System.out.println("\n删除成功,还需要进行以下其他操作吗？");
                            } else {
                                System.out.println("\n删除失败");
                            }
                        }
                        //==========================图书名模糊查询======================
                        if (aSelect == 5) {
                            System.out.println("请输入图书模糊查询的包含字");
                            String bookLikeN = scanner.nextLine();
                            List<Books> booksList = administratorImpl.findBookNameLike(bookLikeN);
                            booksList.forEach(b -> System.out.println(b));
                        }
                        //==========================查询所有用户======================
                        if (aSelect == 6) {
                            List<User> userList = administratorImpl.findAllUser();
                            userList.forEach(u -> System.out.println(u));
                        }
                        //==========================用户模糊查询======================
                        if (aSelect == 7) {
                            System.out.println("请输入用户模糊查询的包含字：");
                            String userLikeN = scanner.nextLine();
                            List<User> userList = administratorImpl.findUserNameLike(userLikeN);
                            userList.forEach(u -> System.out.println(u));
                        }
                        //==========================注销用户=========================
                        if (aSelect == 8) {
                            System.out.println("请输入要注销的用户名：");
                            String delUserN = scanner.nextLine();
                            boolean b = administratorImpl.deleteUser(delUserN);
                            if (b) {
                                System.out.println("\n注销用户成功,还需要进行以下其他操作吗？");
                            } else {
                                System.out.println("\n注销用户失败");
                            }
                        }
                        //退出操作
                        if (aSelect == 9) {
                            break;
                        }
                        //退出系统
                        if (aSelect == 10) {
                            sel_lg = 3;
                            break;
                        }
                    }
                } else {
                    System.out.println("登录失败，请重新输入选择");
                }
            }
            //用户操作
            if (sel_lg == 2) {
                while (true) {
                    System.out.println("=================================\n1.用户注册 2.用户登录 3.退出操作 4.退出系统\n" +
                            "=================================\n" +
                            "请选择，请正确输入需要操作的选项！");
                    String u_Sel_s = scanner.nextLine();
                    //保证输入选择项符合规则，若输入错误选项则重新输入
                    if(u_Sel_s.compareTo("1")<0||u_Sel_s.compareTo("4")>0){
                        continue;
                    }
                    int u_Sel = Integer.parseInt(u_Sel_s);
                    //==========================用户注册=========================
                    if (u_Sel == 1) {
                        User user = new User();
                        //添加用户名
                        System.out.println("请输入用户名：");
                        String u_AddN = scanner.nextLine();
                        user.setUsername(u_AddN);
                        //请输入密码
                        System.out.println("请输入密码：");
                        String u_AddPwd = scanner.nextLine();
                        user.setPassword(u_AddPwd);
                        //请输入个人性别
                        System.out.println("请输入个人性别：");
                        String u_AddSex = scanner.nextLine();
                        user.setSex(u_AddSex);
                        //请输入生日日期
                        System.out.println("请按照yyyy-mm-dd格式输入生日日期：");
                        String u_AddBir = scanner.nextLine();
                        user.setBirthday(u_AddBir);
                        //请输入地址
                        System.out.println("请输入地址：");
                        String u_Address = scanner.nextLine();
                        user.setAddress(u_Address);
                        //请输入年龄
                        System.out.println("请输入年龄：");
                        int u_AddAge = Integer.parseInt(scanner.nextLine());
                        user.setAge(u_AddAge);

                        boolean b = userImpl.addUser(user);
                        if (b) {
                            System.out.println("添加用户成功，id为：" + user.getStuNo() + "\n还需要进行以下其他操作吗？");
                        } else {
                            System.out.println("添加用户失败");
                        }
                    }
                    //==========================用户登录及后续操作=========================
                    if (u_Sel == 2) {
                        System.out.println("请输入用户名");
                        String u_LogU = scanner.nextLine();
                        System.out.println("请输入密码");
                        String u_LogP = scanner.nextLine();
                        User user = userImpl.LogIn(u_LogU, u_LogP);
                        if (user != null) {
                            System.out.println("用户：" + user.getUsername() + "登录成功" + "\n还需要进行以下其他操作吗？");
                            while (true){
                                System.out.println("=================================\n" +
                                        "1.查询书籍 2.书名搜索 3.修改密码 4.查看个人信息 5.修改个人信息 6.退出系统 7.退出操作\n" +
                                        "=================================\n" +
                                        "请选择，请正确输入需要操作的选项！");
                                String u_LogSel_s = scanner.nextLine();
                                //保证输入选择项符合规则，若输入错误选项则重新输入
                                if(u_LogSel_s.compareTo("1")<0||u_LogSel_s.compareTo("7")>0){
                                    System.out.println("请重新选择");
                                    continue;
                                }
                                int u_LogSel = Integer.parseInt(u_LogSel_s);
                                //==========================查询书籍=========================
                                if(u_LogSel == 1){
                                    List<Books> booksList = userImpl.findAllBooks();
                                    booksList.forEach(b-> System.out.println(b));
                                }
                                //==========================书名搜索=========================
                                if(u_LogSel == 2){
                                    System.out.println("请输入搜索书籍的名字：");
                                    String u_FindBN = scanner.nextLine();
                                    Books books = userImpl.findBooksByName(u_FindBN);
                                    System.out.println(books);
                                }
                                //==========================修改密码=========================
                                if(u_LogSel == 3){
                                    System.out.println("请输入新密码：");
                                    String u_UpPwd = scanner.nextLine();
                                    boolean b = userImpl.updateUserPassword(u_LogU,u_UpPwd);
                                    if(b){
                                        System.out.println("修改密码成功");
                                    }else {
                                        System.out.println("修改密码失败");
                                    }
                                }
                                //==========================查看个人信息=========================
                                if(u_LogSel == 4){
                                    System.out.println("以下是您的个人信息：");
                                    User user1 = userImpl.findUserByName(u_LogU);
                                    System.out.println(user1);
                                }
                                //==========================修改个人信息=========================
                                if (u_LogSel==5){
                                    //修改用户名
                                    System.out.println("请输入要修改的用户名，若不修改用户名请按Enter键进行下一步：");
                                    String u_UpUN = scanner.nextLine();
                                    if(!u_UpUN.isEmpty()){
                                        user.setUsername(u_UpUN);
                                    }
                                    //修改个人性别
                                    System.out.println("请输入要修改的个人性别，若不修改个人性别请按Enter键进行下一步：");
                                    String u_UpSex = scanner.nextLine();
                                    if(!u_UpSex.isEmpty()){
                                        user.setSex(u_UpSex);
                                    }
                                    //修改生日日期
                                    System.out.println("请按照yyyy-mm-dd格式输入要修改的生日日期，若不修改生日日期请按Enter键进行下一步：");
                                    String u_UpBir = scanner.nextLine();
                                    if(!u_UpBir.isEmpty()){
                                        user.setBirthday(u_UpBir);
                                    }
                                    //修改个人年龄
                                    System.out.println("请输入要修改的年龄数，若不修改年龄请按Enter键进行下一步：");
                                    String u_UpAge_s= scanner.nextLine();
                                    if(!u_UpAge_s.isEmpty()){
                                        int u_UpAge = Integer.parseInt(u_UpAge_s);
                                        user.setAge(u_UpAge);
                                    }
                                    //修改地址
                                    System.out.println("请输入要修改的地址，若不修改年龄请按Enter键进行下一步：");
                                    String u_UpAddress= scanner.nextLine();
                                    if(!u_UpAddress.isEmpty()){
                                        user.setAddress(u_UpAddress);
                                    }
                                    boolean b = userImpl.updateUser(user);
                                    if (b) {
                                        System.out.println("\n修改成功");
                                    } else {
                                        System.out.println("\n修改失败");
                                    }
                                }
                                //==========================退出系统=========================
                                if(u_LogSel == 6){
                                    u_Sel = 4;
                                    break;
                                }
                                //==========================退出操作=========================
                                if (u_LogSel == 7){
                                    break;
                                }

                            }


                        } else {
                            System.out.println("用户登录失败，请重新选择！");
                        }
                        //==========================退出操作=========================
                        if (u_Sel == 3) {
                            break;
                        }
                        //==========================退出系统=========================
                        if (u_Sel == 4) {
                            sel_lg = 3;
                            break;
                        }
                    }
                    //==========================退出操作=========================
                    if (u_Sel == 3){
                        break;
                    }
                    //==========================退出系统=========================
                    if (u_Sel == 4){
                        sel_lg = 3;
                        break;

                    }
                }
            }
            //==========================退出系统=========================
            if (sel_lg == 3) {
                    break;
                }
        }
    }
}