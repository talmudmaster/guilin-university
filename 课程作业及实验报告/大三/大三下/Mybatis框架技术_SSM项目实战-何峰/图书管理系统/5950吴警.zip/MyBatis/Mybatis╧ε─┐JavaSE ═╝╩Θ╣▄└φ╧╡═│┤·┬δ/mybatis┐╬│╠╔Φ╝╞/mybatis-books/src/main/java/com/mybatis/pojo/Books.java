package com.mybatis.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Books {
//    书名编号
    private String id;
//    书名
    private String bookName;
//    作者
    private String author;
//    价格
    private double price;
//    出版日期
    private String publishDate;
//    出版社
    private String press;
//    图书类型
    private String bookType;
//    印刷次数
    private int frequency;
//    上架时间
    private String shelfTime;
}
