package com.mybatis.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class User {
//    学生编号
    private int stuNo;
//    姓名
    private String username;
//    密码
    private String password;
//    性别
    private String sex;
//    生日
    private String birthday;
//    年龄
    private int age;
//    地址
    private String address;
//    注册时间
    private String createTime;
}
