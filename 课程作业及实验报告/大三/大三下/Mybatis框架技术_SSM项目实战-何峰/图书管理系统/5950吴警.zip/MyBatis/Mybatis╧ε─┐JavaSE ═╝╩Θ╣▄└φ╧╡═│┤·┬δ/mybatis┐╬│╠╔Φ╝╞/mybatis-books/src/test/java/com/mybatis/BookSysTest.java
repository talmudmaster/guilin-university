package com.mybatis;

import cn.hutool.core.date.DateTime;
import com.mybatis.Impl.AdministratorImpl;
import com.mybatis.Impl.UserImpl;
import com.mybatis.dao.AdministratorMapper;
import com.mybatis.pojo.Administrator;
import com.mybatis.pojo.Books;
import com.mybatis.pojo.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class BookSysTest {
//    会话工厂
    SqlSessionFactory sqlSessionFactory;
    @Before
    public void setUp(){
        try {
            InputStream inputStream = Resources.getResourceAsStream("SqlMapConfig.xml");
            sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    SqlSessionFactory factory = mybatis.setUp();
    AdministratorImpl administratorImpl = new AdministratorImpl(factory);
    UserImpl userImpl = new UserImpl(factory);

    @Test
    public  void LogIn(){
//        SqlSession sqlSession = sqlSessionFactory.openSession();
//        AdministratorMapper administratorMapper = sqlSession.getMapper(AdministratorMapper.class);
        Administrator admin = administratorImpl.logIn("admin","123456");
        if(admin!=null){
            System.out.println(admin);
            System.out.println("登录成功");
        }
    }
//添加信息
    @Test
    public void getAddBooks(){
        Books books = new Books();
        books.setBookName("今天520不上课");
        books.setAuthor("何老师");
        books.setPrice(520.01);
        books.setPublishDate("20060520");
        books.setPress("桂院计算机研究所");
        books.setBookType("校园生活");
        books.setFrequency(52000);
        books.setShelfTime("20070520");
        boolean b =administratorImpl.addBook(books);
        if(b){
            System.out.println("增加成功");
        }
    }
//查看所有图书信息
    @Test
    public void listFindAllBooks(){
        List<Books> books = administratorImpl.findAllBooks();
        books.forEach(b-> System.out.println(b));
    }

//    更新图书信息
    @Test
    public void getUpdateBooks(){
        Books books = administratorImpl.findBooksByName("修改一次");
        books.setPrice(110.01);
        books.setBookName("修改一次");
        books.setPublishDate("20000705");
        boolean b = administratorImpl.updateBook(books);
        if(b){
            System.out.println("修改成功");
        }
    }

//    删除图书信息
    @Test
    public void getDeleteBook(){
        boolean b = administratorImpl.deleteBook("MySQL从入门到劝退");
        if(b){
            System.out.println("删除成功");
        }
    }
//    书名模糊查询
    @Test
    public void listFindBookNameLike(){
        List<Books> books = administratorImpl.findBookNameLike("MySQL从入门到劝退");
        books.forEach(b-> System.out.println(b));
    }
//    查看所有用户
    @Test
    public void listFindAllUser(){
        List<User> users = administratorImpl.findAllUser();
        users.forEach(u-> System.out.println(u));
    }

    //    用户名模糊查询
    @Test
    public void listFindUserNameLike(){
        List<User> users = administratorImpl.findUserNameLike("f");
        users.forEach(u-> System.out.println(u));
    }
    //注销用户
    @Test
    public void getDeleteUser(){
        boolean b = administratorImpl.deleteUser("cf");
        if(b){
            System.out.println("删除成功");
        }
    }
//    用户实现方法⏬⏬

//    用户注册
    @Test
    public void addUser(){
        User user = new User();
        user.setUsername("张红");
        user.setPassword("123456Aa");
        user.setSex("女");
        user.setBirthday("2000-01-01");
        user.setAge(18);
        user.setAddress("苏州");
        boolean b = userImpl.addUser(user);
        if(b){
            System.out.println("添加成功"+user.getStuNo());
        }else {
            System.out.println("添加失败");
        }
    }
//    用户登录
    @Test
    public void logIn_U(){
        User user = userImpl.LogIn("pp","123465asd");
        System.out.println(user);
    }
//1、查询所有书籍
    @Test
    public void listFindAllBooks_U(){
        List<Books> books = userImpl.findAllBooks();
        books.forEach(b-> System.out.println(b));
    }
//2、修改密码
    @Test
    public void getUpdateUserPassword(){
        User user = userImpl.findUserByName("cf");
        boolean b = userImpl.updateUserPassword(user.getUsername(),"7654321zxc");

        if(b){
            System.out.println("修改成功");
        }else {
            System.out.println("修改失败");
        }
    }
//3、根据书名搜索
    @Test
    public void getFindBookByName(){
        Books book = userImpl.findBooksByName("MySQL从入门到劝退");
        System.out.println(book);
    }
//4、查看个人注册信息
    @Test
    public void getFindUserByName(){
        User user = userImpl.findUserByName("cf");
        System.out.println(user);
    }
//5、修改个人信息
    @Test
    public void UpdateUser(){
        User user=userImpl.findUserByName("fff");
        user.setUsername("ffs");
        user.setPassword("123456A");
        user.setAddress("南京");
        boolean b = userImpl.updateUser(user);
        if (b){
            System.out.println("修改成功");
        }else {
            System.out.println("修改失败");
        }
    }
//6、退出操作
//7、A、借书、B、还书
}
