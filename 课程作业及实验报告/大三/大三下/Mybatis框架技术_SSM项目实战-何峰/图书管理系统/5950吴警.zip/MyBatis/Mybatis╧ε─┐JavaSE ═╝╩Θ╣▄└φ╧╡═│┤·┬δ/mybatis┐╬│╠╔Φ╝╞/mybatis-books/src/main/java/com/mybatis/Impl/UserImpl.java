package com.mybatis.Impl;

import cn.hutool.core.date.DateTime;
import com.mybatis.dao.AdministratorMapper;
import com.mybatis.dao.UserMapper;
import com.mybatis.pojo.Books;
import com.mybatis.pojo.User;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.After;
import org.junit.Before;

import java.util.List;

public class UserImpl implements UserMapper {
    private SqlSessionFactory sqlSessionFactory;

    public UserImpl(SqlSessionFactory sqlSessionFactory){
        this.sqlSessionFactory = sqlSessionFactory;
    }

    @Override
    public boolean addUser(User user) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        user.setCreateTime(new DateTime().toString().substring(0,10));
        boolean b = userMapper.addUser(user);
        sqlSession.commit();
        sqlSession.close();
        return b;
    }

    @Override
    public User LogIn(String username, String password) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        User user = userMapper.LogIn(username,password);
        return user;
    }

    @Override
    public List<Books> findAllBooks() {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        List<Books> booksList= userMapper.findAllBooks();
        return booksList;
    }

    @Override
    public boolean updateUserPassword(String username,String password) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        boolean b = userMapper.updateUserPassword(username,password);
        sqlSession.commit();
        sqlSession.close();
        return b;
    }

    @Override
    public Books findBooksByName(String bookname) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        return userMapper.findBooksByName(bookname);
    }

    @Override
    public User findUserByName(String username) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        return userMapper.findUserByName(username);
    }

    @Override
    public boolean updateUser(User user) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        boolean b = userMapper.updateUser(user);
        sqlSession.commit();
        sqlSession.close();
        return b;
    }
}
