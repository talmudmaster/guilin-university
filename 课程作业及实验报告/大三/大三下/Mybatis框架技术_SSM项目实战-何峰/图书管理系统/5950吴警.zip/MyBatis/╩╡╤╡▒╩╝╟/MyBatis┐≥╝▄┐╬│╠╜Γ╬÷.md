# MyBatis框架课程解析

## SSM技术架构

```ABAP
Spring与MyBatis整合进行数据操作
Spring与SpringMVC整合进行数据显示
```

## 后端框架：SSM+SpringBoot

```ABAP
 Spring（AOP/IOC）==>CUP（中央处理器）
 SpringMVC（View视图层框架）==>网页数据展示
 MyBatis（持久层框架）==>BD CRUD
 SpringBoot框架
```

# 课程目录（JavaEE）

1. 开发环境

2. SpringBoot开发环境的搭建

3. SpringBoot项目结构以及基础配置

4. YMAL语法

5. SpringBoot数据源、连接池

6. SpringBoot整合MyBatis

7. MyBatis框架知识点

   ```ABAP
   Mybatis基础操作
   MyBatis主配置文件
   MyBatis代理开发Dao层
   MyBatis输入输出映射
   MyBatis动态SQL
   MyBatis高级映射（1:1、1:n、n:n）
   MyBatis延迟加载
   MyBatis分页插件pageHelper
   MyBatis逆向工程
   ```

8. MyBatis-Plus

9. **Spring Data JPA**

10. SpringBoot整合MyBatis综合应用

11. SpringBoot整合Spring（SpringMVC）

12. Thymeleaf模板

13. 视图UI组件（BootStrap/LayUI）数据显示

14. SpringBoot本地上传操作

15. SpringBoot整合云端上传（七牛云）

16. SpringBoot综合应用-购物车操作

17. 沙箱支付（支付宝支付）

18. Shiro权限框架

19. SpringBoot整合Shiro

20. Readis缓存框架

21. SpringBoot整合Redis

22. 第三方整合

23. 消息队列（RabbitMQ、kafka、ActiveMQ）

24. SpringBoot综合项目实训

25. 前后端分离（Vue/SpringBoot）

26. SpringCloud（微服务）

# 开发环境

- IDEA
- JDK1.8
- Maven3.6
  - 镜像
  - 本地仓库
- MySQL8
- SpringBoot2.6系列
- MyBatis

# MyBatis简介

MyBatis是一个半自动化的ORM（持久层）框架，它支持自定义 SQL、存储过程以及高级映射。MyBatis 免除了几乎所有的 JDBC 代码以及设置参数和获取结果集的工作。还可以通过简单的 XML 或注解来配置和映射原始类型、接口和 Java POJO（Plain Old Java Objects，普通Java 对象）为数据库中的记录。

## 持久层技术解决方案：

```ABAP
JDBC技术-->COnnection、PreparedStatement、ResultSet
Apache的DBUtils-->对jdbc的封装
Spring的jdbcTemplate-->Spring中对jdbc的简单封装
Spring Data JPA
Hibernate
MyBatis
注意：以上这些都不是框架（JDBC是规范，DBUtils、jdbcTemplate都是封装的工具集）
```

## MyBatis架构

主要分为三层：

```
API接口层：提供给外部使用的接口API，开发人员通过这些接口开操作数据库，接口层接收请求会调用数据处理层来完成具体数据的处理
数据处理层：负责具体的SQL查找、SQL解析、SQL执行和执行结果映射，主要的目的是根据调用的请求完成一次数据库操作（CRUD）
基础支撑层：负责最基础的功能支撑，包括连接数据库管理、事务管理、配置加载、缓存处理等一些共性配置，在开发中一般将抽取出来作为组件，为上层数据处理层提供基础支撑
```

## ![](D:\图片\mybatis架构图.jpg)MyBatis入门

需求：

```
根据id查询信息
根据名称模糊查询信息
添加、修改、更新信息
```

注意：掌握并完成以上功能需求，基本上就掌握MyBatis基本操作，具体MyBatis项目的搭建及功能的完成

### 搭建Maven项目	

- 安装lombok插件
- 模块化方式构建项目

### 引入MyBatis依赖-pom.xml

```xml
<dependencies>
    <!--        MyBatis框架依赖-->
    <dependency>
        <groupId>org.mybatis</groupId>
        <artifactId>mybatis</artifactId>
        <version>3.5.9</version>
    </dependency>
    <!--        日志依赖-->
    <dependency>
        <groupId>log4j</groupId>
        <artifactId>log4j</artifactId>
        <version>1.2.17</version>
    </dependency>
    <!--       MySQL依赖-->
    <dependency>
        <groupId>mysql</groupId>
        <artifactId>mysql-connector-java</artifactId>
        <version>8.0.28</version>
    </dependency>
    <!--        单元测试依赖-->
    <dependency>
        <groupId>junit</groupId>
        <artifactId>junit</artifactId>
        <version>4.13.2</version>
    </dependency>

    <!--        封装实体类的插件-->
    <dependency>
        <groupId>org.projectlombok</groupId>
        <artifactId>lombok</artifactId>
        <version>1.18.24</version>
    </dependency>
    <!--        糊涂工具包-->
    <dependency>
        <groupId>cn.hutool</groupId>
        <artifactId>hutool-all</artifactId>
        <version>5.8.0</version>
    </dependency>
</dependencies>
```

### 设置全局配置文件-SqlMapConfig.xml

通过对MyBatis框架架构的了解，知道MyBatis需要配置一个全局配置文件SqlMapConfig.xml，这个文件是用来配置MyBatis的运行环境，即：数据源、事务等相关信息。

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE configuration
        PUBLIC "-//mybatis.org//DTD Config 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-config.dtd">
<configuration>
<!--    加载连接数据库的资源文件-->
    <properties resource="jdbcConfig.properties"/>
<!--    定义别名-->
    <typeAliases>
        <package name="com.mybatis.pojo"/>
    </typeAliases>
<!--    配置MyBatis全局变量-->
    <environments default="development">
        <environment id="development">
<!--            使用JDBC事务管理-->
            <transactionManager type="JDBC"/>
<!--           数据库连接池-->
            <dataSource type="POOLED">
                <property name="driver" value="${driver}"/>
                <property name="url" value="${url}"/>
                <property name="username" value="${username}"/>
                <property name="password" value="${password}"/>
            </dataSource>
        </environment>
    </environments>
<!--配置映射文件-->
    <mappers >
    <mapper resource="mapper/UserAndOrderMapper.xml"/>
    </mappers>
</configuration>
```

### 创建数据库连接-jdbcConfig.properties

```properties
driver = com.mysql.cj.jdbc.Driver
url = jdbc:mysql://localhost:3306/MyBatisDB
username = root
password = Rango6258
```

### 创建数据库表对应的POJO实体类

 * 封装
 * 1、get/set
 * 2、有参构造
 * 3、无参构造
 * 4、toString

实例代码：

```java
@Data//get/set、toString
@NoArgsConstructor//无参构造
@AllArgsConstructor//有参构造
public class User {
    private Integer id;
    private String username;
    private String sex;
    private String birthday;
//    private String keyId;

    public User(String username, String sex, String birthday) {
        this.username = username;
        this.sex = sex;
        this.birthday = birthday;
    }
}

```

### 创建映射文件

实例代码

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE mapper
        PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="myBatisTest">
<!--
根据id查询信息
根据名称模糊查询信息:select * from user where username like '%#{value}'
添加、修改、更新信息
-->
<!--
    select:标签，用于执行数据库查询
                id：唯一标识
                parameterType：指定输入参数的类型，要和数据库中的保持一致
                resultType：指定输出结果集的类型，即查询结果所映射的java对象
                #{}：表示一个占位符，用来接收输入参数
                #{id}：id标识接收输入的参数，参数名为id，如果输入参数是简单类型，参数名可以任意
                ${}:表示拼接sql语句，将接收到的参数内容不加任何的修饰，直接拼接到sql语句中（存在SQL注入）
                concat('%',#{value},'%')：字符串拼接，防止SQL注入

     添加操作
                主键：
                    1、自增：无需为主键添加数据
                    2、 非自增：
-->
<!--  根据id查询信息  输入参数类型-输出结果集-->
    <select id="findUserById" parameterType="integer" resultType="pojo.User">
        select * from user where id=#{id}
    </select>

<!--    根据名称模糊查询信息 返回多条数据-集合List<User>-->
    <select id="findUserByName"  parameterType="String" resultType="pojo.User">
--         select * from user where username like "%${value}%"
            select * from user where username like CONCAT('%',#{value },'%')
    </select>

<!--    添加、修改、更新信息-->
<!--
        自增id主键：insert into user (username, sex,birthday) values (#{username},#{sex},#{birthday})
        非自增keyId主键-绑定主键-生成时间-生成32位序列
            <selectKey keyProperty="keyId" order="BEFORE" resultType="String">
                select uuid()
            </selectKey>
            insert into user (keyId,id,username, sex,birthday) values (#{keyId},#{id},#{username},#{sex},#{birthday})
-->
    <!--添加-->
    <insert id="insertUser" parameterType="pojo.User" >
        insert into user (username, sex,birthday) values (#{username},#{sex},#{birthday})
    </insert>

    <!--删除-->
    <delete id="deleteUserById" parameterType="integer">
        delete from user where id=#{id}
    </delete>

<!--    修改更新-->
    <update id="updateUserById" parameterType="pojo.User">
        update user set username=#{username},sex=#{sex} where id=#{id}
    </update>
</mapper>
```

### 单元测试

```java
public class MybatisFirstTest {
    //因为所有的操作都需要获取SqlSession实例，所有抽取成一个方法
    public SqlSession getSession() throws IOException {
        //得到配置文件的流
        InputStream inputStream = Resources.getResourceAsStream("SqlMapConfig.xml");
        //创建会话工厂SqlSessionFactory
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        //通过工厂得到SqlSession实例
        SqlSession sqlSession = sqlSessionFactory.openSession();
        return sqlSession;
    }

    //根据ID查询
    @Test
    public void findUserById() throws IOException {
        //获取SqlSession对象
        SqlSession sqlSession = getSession();
        //调用sql方法-根据ID查询
        User user = sqlSession.selectOne("myBatisTest.findUserById",1);
        System.out.println(user.toString());
        //释放连接资源
        sqlSession.close();
    }

    //模糊查询
    @Test
    public void findUserByName() throws IOException {
        //获取查询条件
        String key="大";
        //获取SqlSession对象
        SqlSession sqlSession = getSession();
        //调用sql方法-模糊查询，返回结果集
        List<User> list = sqlSession.selectList("myBatisTest.findUserByName",key);
        System.out.println("模糊查询");
        //循环遍历结果集
        for (User user : list){
            System.out.println(user.toString());
        }
        //释放连接资源
        sqlSession.close();
    }

    //添加
//    @Test
    public void insertUser() throws IOException {
//        User key = new User();
//        key.setId(5);
//        key.setUsername("珊迪");
//        key.setSex("女");
//        key.setBirthday("2001-01-01");
//        自增id主键
        User key = new User("陈大呆瓜","男","2000-01-01");
//        非自增keyId主键
//        User key = new User(1,"呆头","男","2000-01-01");
        //调用sql方法
        SqlSession sqlSession = getSession();
        int k = sqlSession.insert("myBatisTest.insertUser",key);
        // 提交事务
        sqlSession.commit();
        System.out.println("添加"+k);
        //释放连接资源
        sqlSession.close();
    }

    //删除
    @Test
    public void deleteUserById() throws IOException {
        int key=1;
        //调用sql方法
        SqlSession sqlSession = getSession();
        int k = sqlSession.delete("myBatisTest.deleteUserById",key);
        // 提交事务
        sqlSession.commit();
        System.out.println("删除"+k);
        //释放连接资源
        sqlSession.close();
    }

    //修改更新
    @Test
    public void updateUserById() throws IOException {
        User key = new User();
        key.setId(2);
        key.setUsername("陈大祖师");
        key.setSex("女");
        SqlSession sqlSession = getSession();
        int k = sqlSession.update("myBatisTest.updateUserById",key);
        // 提交事务
        sqlSession.commit();
        System.out.println("修改更新"+k);
        //释放连接资源
        sqlSession.close();

    }
}

```

## MVC

### 简介

MVC(model-view-controller)是软件**开发的一种模式**，即把一个应用的输入、处理、输出流程按照model、view、controller方式进行划分，主要将模型层和视图层的代码进行分离，使软件结构更加清晰，各司其职，便于开发和维护。
通常意义上的三层架构就是将整个业务应用划分为：

```
表现层(UI)：展现给用户的界面，即用户使用系统是所见所得
业务逻辑层(BLL)：针对具体问题的操作，也可以说是对数据层的操作，对数据业务逻辑处理
数据访问层(DAL)：该层所做事务直接操作数据库，针对数据库的CRUD操作
```

区分层次的目的：高内聚、低耦合的思想：

```
M:Model
	与数据有关的层，在项目中一般指Dao(数据接口)层与DTO(数据表现层与业务逻辑层之间传递数据的对象)层
V:View
	与显示数据相关的层，在项目中一般指页面(JSP、HTML、Thymeleaf)
C:Controller
	连接View和Model在项目中一般指servlet与service。View负责前端的人机交互，页面需要显示的数据与页面产生需要保存的数据都是由Controller层来与Model层沟通
```

### javaEE的三层架构

​	在JAVAEE项目开发模式中，其对应符合MVC设计模式，只是JavaBean只负责数据封装，service负责业务逻辑处理，DAO层负责数据库访问
​	

### 原始Dao开发

MyBatis框架中支持原始Dao的开发。
项目开发命名规范【英文】：

```
项目名：项目名的组成所有单词字母都是小写，或者单词间使用下划线分割
	Eg:neusoftoa\neusoft_oa
包名：	见名知意，com.包名
	Eg；com.neusoftoa.dao\com.neusoftoa.pojo
类名：首字母大写，采用大驼峰命名
	Eg：UserDao
方法名：首字母小写，采用小驼峰命名
	Eg：findUserById()
标识符（变量）：采用小驼峰命名
	Eg：userName
常量：单词字母大写
	Eg：MAX
```

## Mapper动态代理

原始Dao开发存在的问题：

```
从代码的实现过程中，发现接口的实现类中存在大量重复的代码，从设计的角度，可以进一步优化
在调用sqlSession会话时，存在很多的硬编码操作
在SqlSession的方法中，要求传入的参数都是Object类型，如果传递的参数有错误，编译时不会报错，执行时才会报错，不利于开发
```
所谓的Mapper动态代理（Mapper接口，相当于dao接口），使用Mapper接口的方式来开发Dao，其将自动生成其代理类来进行操作，其中**Mapper代理使用的是JDK的代理策略。**

采用Mapper代理的方式开发规则【使用Mapper动态代理开发Dao层（接口）】：

```
Mapper接口的全限定名要和Mapper映射文件的namesapce值一致
Mapper接口中的方法名称要和Mapper映射文件的标签块的id一致
Mapper接口的方法参数类型要和Mapper映射文件的parameterType值一致
mapper接口的方法返回值类型要和Mapper映射文件的标签快的resultType值一致
```
创建实体类-示例代码：

```java
/*
*@Data，构造get/set、toString
*@AllArgsConstructor，有参构造
*@NoArgsConstructor，无参构造
*/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Student {
    private int id;
    private String username;
    private String password;
    private String sex;
    private String birthday;
    private String address;
}

```

创建接口类-示例代码：

```java
//接口类
public interface StudentMapper {
	//添加
    int insertStudent(Student student);
	//查询所有
    List<Student> findStudentAll();
	//根据id查询
    Student findStudentById(int id);
	//根据用户名和密码查询
    List<Student> findStudentByNameAndPass(Map map);
	//根据用户名模糊查询
    List<Student> findStudentByLinkName(String name);
	//修改
    int updateStudentById(Student student);
	//删除
    int deleteStudentById(int id);
	//查询总记录数
    int studentByCount();
}
```
创建数据库操作映射文件-示例代码：

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE mapper
        PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<!--
    namespace命名空间，对SQL进行分类化管理，即SQL隔离
    在mapper动态代理开发中，namespace=mapper接口地址
-->
<mapper namespace="com.mybatis.mapper.StudentMapper">
<!--进行结果映射：数据库表字段和实体类属性映射绑定
      id：唯一标识
      type：绑定类型
      <id>：数据库表主键
      <result>：数据库表非主键
         column:数据库中的表字段名
         property:实体类中对应的属性名
-->
    <resultMap id="StudentResultMap" type="student">
        <id column="id" property="id" javaType="java.lang.Integer"/>
        <result column="sex" property="sex" javaType="java.lang.String"/>
    </resultMap>
<!--插入数据-->
    <insert id="insertStudent" parameterType="com.mybatis.pojo.Student" keyProperty="id" useGeneratedKeys="true">
        insert into  student(username,password,sex,birthday,address)
            values(#{username},#{password},#{sex},#{birthday},#{address})
    </insert>
<!--  查询所有  -->
    <select id="findStudentAll" resultType="com.mybatis.pojo.Student">
        select * from student
    </select>
<!--根据id查询-->
    <select id="findStudentById" resultType="com.mybatis.pojo.Student">
        select * from student where id=#{id}
    </select>
<!-- 根据指定属性查询  -->
    <select id="findStudentByNameAndPass" resultType="com.mybatis.pojo.Student">
        select * from student where username=#{name} and password=#{pass}
    </select>
<!--根据姓名模糊查询-->
    <select id="findStudentByLinkName" resultType="com.mybatis.pojo.Student">
        select * from student where username like CONCAT('%',#{name},'%')
    </select>
<!--  根据id修改 -->
    <update id="updateStudentById">
        update student set username=#{username},password=#{password} where id=#{id}
    </update>
<!--根据id删除-->
    <delete id="deleteStudentById">
        delete from student where id=#{id}
    </delete>
<!--  查询记录数 -->
    <select id="studentByCount" resultType="java.lang.Integer">
        select count(*) from student
    </select>
</mapper>
```

创建测试类-示例代码：

```java


//测试类
public class StudentMapperTest {  	
	private  SqlSessionFactory sqlSessionFactory;
	//创建会话工厂-SqlSessionFactory,在执行测试之前执行的方法
    @Before 
    public void setUp(){
        try {//捕获异常
			//获取配置流对象
            InputStream inputStream = Resources.getResourceAsStream("SqlMapConfig.xml");
			//创建会话工厂
            sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void StudentByCount(){
        //创建会话实例
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //获取动态代理实例
        StudentMapper studentMapper = sqlSession.getMapper(StudentMapper.class);
        int key = studentMapper.studentByCount();
        System.out.println("记录条数："+key);
    }
}
```
# MyBatis分页

Mybatis中分页的实现方式：

**使用limit分页**:

```mysql
select * from student limit((pageNum-1)*pageSize,pageSize)
--pageNum：当前页
--pageSize：每页显示的记录数
```

**使用RowBound类分页**

**使用PageHelpe分页插件实现分页**

pageHelper分页插件是一个非常实用的MyBatis分页插件，可以快速地实现MyBatis分页功能，而且pageHelper显著的优点是分页和Mapper.xml完全解耦，有效避免了直接写分页SQL语句，然后重写SQL，添加对应的物理分页语句（拼接SQL），来实现分页操作

实现原理：

​	分页插件的基本原理是使用MyBatis提供的插件接口，实现自定义插件，在插件的拦截器内拦截待执行的SQL语句

加载pageHelper的依赖

```xml
<!--        page helper分页依赖-->
        <dependency>
            <groupId>com.github.pagehelper</groupId>
            <artifactId>pagehelper</artifactId>
            <version>5.1.11</version>
        </dependency>
```

配置分页插件拦截器

```xml
<plugins>
    <!-- com.github.pagehelper为PageHelper类所在包名 -->
    <plugin interceptor="com.github.pagehelper.PageInterceptor">
    </plugin>
</plugins>
```

拦截分页映射：

```sql
<select id="studentPageHelper" resultType="student">
    select * from student
</select>
```

拦截分页方法：

```java
@Test
    public void studentPageHelper(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        StudentMapper studentMapper = sqlSession.getMapper(StudentMapper.class);

        Page page = PageHelper.startPage(1, 5);
        List<Student> studentList = studentMapper.studentPageHelper();
        PageInfo pageInfo = page.toPageInfo();
        System.out.println("总页数："+pageInfo.getPages());
        System.out.println("总记录数："+pageInfo.getTotal());
        System.out.println("当前页："+pageInfo.getPageNum());
        System.out.println("每页记录数："+pageInfo.getPageSize());
        System.out.println("前一页："+pageInfo.getPrePage());
        System.out.println("下一页："+pageInfo.getNextPage());

        int pages[] = pageInfo.getNavigatepageNums();
        System.out.println(pages.toString());
        for(int i=0;i<pages.length;i++){
            System.out.println(pages[1]);
        }
        for (Student student:studentList){
            System.out.println(student.toString());
        }
    }
```
分页三要素：
	当前页
	每页记录数
	总记录数
	总页数：总记录数%条数==0？总记录数/每页记录数：总记录数/每页记录数+1

# 动态SQL

传统的JDBC方法，组合SQL语句时需要拼接，稍不注意就会少打空格、标点符号等导致SQL语法错误。Mybatis的动态SQL语句基于OGNL表达式/JSTL，能够解决这种问题。方便在SQL中实现拼接判断的逻辑，可以使用标签组合成灵活的SQL语句，提高开发效率。

## MyBatis动态SQL常用标签：

```
	if：条件判断
	where：简化SQL语句中where条件判断，能够智能的处理and/or,避免多余的语法导致SQL语法错误
	choose（when/otherwise）:相当于java中Switch/case语句
	tirm:对包含的内容加上前缀prefix或者后缀suffix
	set：用于更新操作
	foreach:用于MyBatis硬/in语句查询（批处理）
	bind:在SQL语句中允许构造变量，并将其绑定到当前上下文中
```

## if标签的用法：

​	动态SQL通常有条件包含where子句的一部分
需求：
查询已上架的图书信息，如果传参时有nema就根据name查询，否则查询所有

```xml
<select id="selectBookByName" parameterType="String" resultType="book">
    select * from book where 1=1
    <if test="name!=null">
        and name like CONCAT('%',#{name},'%')
   	</if>
</select>
```
问题【实际开发不可取】：
当没有查询条件时，SQL语句会带上where 1=1
在构造条件时需要添加and关键字
## where标签的用法：
where标签用来拼接条件，与SQL语句中的where相比，where标签在设置的if条件不满足时会自动删除where和and关键字，条件满足时会自动加上where关键字。

```xml
<select id="selectBookByName" parameterType="String" resultType="book">
    select * from book
    <where>
        <if test="name!=null">
            and name like CONCAT('%',#{name},'%')
        </if>
        <if test="imgPath!=null">
            and imgPath=#{imgPath}
        </if>
    </where>
</select>
```

## choose标签的用法：

需求：

条件搜索，如果name不为空，按照name查询；否则如果price不为空，就按照price查询；如果name和price都为空查询所有

```xml
<select id="selectBookByNameOrPrice" parameterType="map" resultType="Book">
    select * from book
    <where>
        <choose>
            <when test="name!=null">name like CONCAT('%',#{name},'%')</when>
            <when test="price!=null">price=#{price}</when>
            <otherwise></otherwise>
        </choose>
    </where>
</select>
```

通过测试，可以得出choose功能类似switch/case,里面的when条件只要有一个满足就会跳出查询结构，如果多个条件都满足，则会按照满足条件的先后顺序选择一个满足的条件执行。choose里面的嵌套when标签的使用和if标签相同，otherwise当所有when标签都不满足时选择改语句执行，一般用于查询操作。

## set标签的用法：

set标签会动态地在行首插入set关键字，并删除额外的逗号，用法与where相似

需求：

修改图书信息

```xml
<update id="updateBookBySet" parameterType="map">
        update book
        <set>
            <if test="sales!=null">sales=#{sales},</if>
            <if test="stock!=null">stock=#{stock}</if>
        </set>
        where id=#{id}
    </update>
```

set标签只有在一个以上的if条件有值的情况插入set关键字，set标签会删除末尾的逗号。

## foreach标签的用法：

对集合进行遍历，通常在构建IN条件语句时使用。可以将一个List实例或数组作为参数对象传递给MyBatis，MyBatis会自动将其包裹在一个Map中，并以名称为键名。List实例的键名为list，数组实例的键名为array。

需求：

根据提供的id列表批量查询/删除数据

```xml
<select id="findBookListIn" parameterType="list" resultType="Book">
    <include refid="selectBookBean"/> where id in
    <foreach collection="list" item="id" open="(" close=")" separator="," >#{id}</foreach>
</select>
<--
    collection：要遍历的集合类型：Array、List、Map
    open：循环开始
    close：循环结束
    separator ：分隔符    
-->
```

测试：

```JAVA
@Test
public void findBookListIn(){
    SqlSession sqlSession = sqlSessionFactory.openSession();
    BookMapper bookMapper = sqlSession.getMapper(BookMapper.class);

//  List<Integer> list = Arrays.asList(3, 6, 9);
//  List<Book> bookList = bookMapper.findBookListIn(list);

// 	int array[]={3,6,9};
// 	List<Book> bookList = bookMapper.findBookArrayIn(array);

    int mapList[]={3,6,9};
    Map<String, Object> map = new HashMap<>();
    map.put("mapList",mapList);
    map.put("author","杨本芳");
    List<Book> bookList = bookMapper.findBookMapIn(map);

    bookList.forEach(book -> System.out.println(book));
}
```

## bind标签的用法：

bind标签允许在OGNL表达式以外创建一个局变量，绑定到当前上下文

使用方法：

```xml
<select id="findBookLikeByNameBind" resultType="Book">
    <include refid="selectBookBean"/>
    <bind name="name" value="'%'+name+'%'"></bind>
    <where>
        <if test="name!=null">and name like #{name} </if>
    </where>
</select>
```

## trim标签的用法：

在MyBatis中除了where+if组合实现多条件查询，还有一个更为灵活的标签trim能够替代之前的做法。

trim一般用于除去SQL语句中多余的and、or、逗号或者给SQL语句前拼接where、set的后缀，可以用于CRUD操作

```xml
trim prefix="前缀" suffix="后缀" prefixOverrides="移除前缀字符串" suffixOverrides="移除后缀字符串">待处理SQL语句</trim>
<--
    prefix:给SQL语句拼接的前缀，为trim包含的内容加上前缀
    suffix:给SQL语句拼接的后缀，为trim包含的内容加上后缀
    prefixOverrides:移除SQL语句前面的关键字或字符，由prefixOverrides定义
    suffixOverrides:移除SQL语句后面的关键字或字符，由suffixOverrides定义
-->
    
<--使用trim标签查找-->
<select id="selectBookByName" parameterType="String" resultType="Book">
	select * from
    <trim prefix="where" prefixOverrides="and">
        <if test="name!=null">
            and name like CONCAT('%',#{name},'%')
        </if>
    </trim>
</select>
    
<--使用trim标签修改-->
<update id="updateBookBySet" parameterType="map">
    update book
    <trim prefix="set id=#{id}," suffix=" where id=#{id}" suffixOverrides=",">
        <if test="sales!=null">sales=#{sales},</if>
        <if test="stock!=null">stock=#{stock},</if>
    </trim>
</update>
```

## Mapper映射文件中特殊字符处理

在mapper映射文件中，有些特殊字符是不允许的，比如<、<=、&都不能正常解析，解析器会把"<"解析为新元素的开始

在实际开发中有两种处理方式：

**1、使用转义符号**

| <     | <=      | >      | >=      | &      |
| ----- | ------- | ------ | ------- | ------ |
| `&lt` | `&lt;=` | `&lt;` | `&lt;=` | `&amp` |

```sql
select * from book where price &lt;=50
```

**2、CDATA方式**

语法：<![CDATA[<=]]>

```sql
select * from book where price <![CDATA[<=]]> 50
```

## 多参数查询操作

映射文件

```xml
<select id="findBooKPriceBetweenAnd" resultType="Book">
    select * from book where price between #{min} and #{max};
</select>
```

### Map结构

```java
//接口
List<Book> findBooKPriceBetweenAnd(Map map);
```

```java
@Test
public void findBooKPriceBetweenAnd(){
    SqlSession sqlSession = sqlSessionFactory.openSession();
    BookMapper bookMapper = sqlSession.getMapper(BookMapper.class);
    Map<String, Object> map = new HashMap<>();
    map.put("min",50);
    map.put("max",90);
    List<Book> bookList = bookMapper.findBooKPriceBetweenAnd(map);
    bookList.forEach(book -> System.out.println(book));
}
```

### 注解绑定

```java
//接口
List<Book> findBooKPriceBetweenAnd(@Param("min") double min, @Param("max") double max);
```

```java
@Test
public void findBooKPriceBetweenAnd(){
    SqlSession sqlSession = sqlSessionFactory.openSession();
    BookMapper bookMapper = sqlSession.getMapper(BookMapper.class);
    double min=50;
    double max=90;
    List<Book> bookList = bookMapper.findBooKPriceBetweenAnd(min,max);
    bookList.forEach(book -> System.out.println(book));
}
```
##关联查询
关联也叫级联,是数据库实体的概念,在数据库中常见的级联关系:
	一对一(1:1):
		Eg:学生-学号
	一对多(1:n):
		Eg:班级-学生
	多对多(n:n):
		Eg:课程-学生

## 订单模型

- 用户表-user:记录购买商品的用户信息
- 订单表-orders:用户所创建订单,购买商品的订单
- 订单明细表-orderdetall:订单详细信息(购买商品的信息)
- 商品表-items:商品信息

## 表与表之间的业务关系:
```apl
分析时需要建立在某个业务意义基础之上
orders-->user:一个订单只属于一个用户,一对一
user-->orders:一个用户可以创建多个订单,一对多
orderdatall-->orders:一个订单明细只属于一个订单,一对一
orders-->orderdatall:一个订单包含多个订单明细,一对多
orderdatall-->items:一个订单明细只对应一个商品信息,一对一
items-->orderdatall:一个商品信息可以出现在多个订单明细中,一对多
```

映射配置：

```xml
<mapper namespace="com.mybatis.mapper.UserAndOrderMapper">
<!--
resultMap，数据库表和实体类绑定
id标签：主键绑定
association标签，用于映射单个对象信息，处理一对一级联关系
    属性：
    columnPrefix：列前缀名，在每个属性前加上前缀
    column：数据库表字段
    property：实体类属性
    javaType：映射的java属性类型
SQL中定义别名，使用as关键字
-->
    <resultMap id="UserAndOrderResultMap" type="Orders">
        <id column="id" property="id"/>
        <result column="user_id" property="user_id"/>
        <result column="number" property="number"/>
        <result column="createTime" property="createTime"/>
        <result column="note" property="note"/>
        <association property="user" columnPrefix="u_"  javaType="User">
<!--            配置User类型的属性-->
            <result column="id" property="id"/>
            <result column="username" property="username"/>
            <result column="sex" property="sex"/>
            <result column="address" property="address"/>
        </association>
    </resultMap>
    <select id="getOrdersByNumber" parameterType="string" resultType="orders" resultMap="UserAndOrderResultMap">
        select  o.* , u.id as u_id , u.username as u_username , u.sex as u_sex , u.address as u_address
        from orders as o , user as u
        where o.user_id=u.id and o.number=#{number}
    </select>
</mapper>
```

一对一（1:1）

- 需求：通过订单号查询订单及用户信息
- 分析：订单号是在订单表中，通过订单表中的user_id字段可以查询到用户信息
- 主表：orders
- 从表：user
- SQL：select * from orders o,user u where o.user_id = u.id and o.number=#{number} 

实现步骤:

一对多（1:n）

- 需求：通过订单号查询订单明细及用户信息
- 分析：通过订单表关联查询订单明细
- 主表：orders
- 从表：orderDetail
- SQL：`select o.*,d.* from orders as o, orderDetail as d where d.order_id=o.id`

多对多（n:n）

# SpringBoot

SpringBoot基于Spring4.0设计，不仅继承了Spring框架原有的优秀特性，而且还通过简化配置来进一步简化了Spring应用的整个搭建和开发过程。另外SpringBoot通过集成大量的框架使得依赖包的版本冲突，以及引用的不稳定性等问题得到了很好的解决。

## SpringBoot开发环境搭建

### 开发环境：

1. Spring Boot 2.6.6
2. Maven
3. JDK 1.8
4. IDEA

### SpringBoot工程结构，主要有三个模块组成：

- sre/main/java：主要存放业务程序
- src/main/resources：存放静态文件和配置文件
  - static：存放所有静态资源，css、js、images
  - template：存放模板页面（html）
  - application.properties：springboot的核心配置文件，相关框架的整合以及以下属性设置都是在此文件中操作。
- src/test/java：编写测试类，用于单元测试

## SpringBoot配置文件

### 全局配置文件

- application.properties
- application.yml

### YMAL语法

yaml是一种标记语言，以数据为中心，比JSON、XML更适合作配置文件

基本语法：

​	键值对：K: V，冒号后面必须有一个空格

​	yml文件文件中是以空格的缩进来控制层级关系，只要是左对齐的一系列数据都是同一层级。

​	yml文件中的属性和值严格区分大小写

​	V值可以是数字、字符串、布尔、数组、集合、对象

```yaml
#定义变量
name:
  springboot
```

yml文件中使用#注释

```yaml
#转义，单引号转字符，双引号转义
message:
  '你好\n陈大祖师'
```

注意：字符串默认不用加引号（单双引号）

### yml文件示例

```yaml
server:
  port: 8081
yamlbean: #映射绑定
  magic: #定义变量
    '你好\n浮生六世'
  #转义，单引号转字符，双引号转义
  message:
    "你好\n陈大祖师"
  map: #对象,map，行内使用{}包围
    k1: v1
    k2: v2
  user: {username: 陈大祖师,password: 123,age: 23}
  array: #数组,list,set，使用-值表示数组中的一个元素
    - java
    - python
    - C++
    - GO
  array2: [java,python,C++,GO]
  list:
    - 吃饭
    - 睡觉
    - 写代码
```

### 属性映射示例：

```java
@Data
@AllArgsConstructor
@NoArgsConstructor
//当前作用：将pojo类实例化到spring容器中
@Component
/*
*告诉SpringBoot将本类中的所有属性和配置文件中相关的配置进行绑定
* prefix = "yamlbean"，表示配置文件中的属性进行一一映射
* 注意：指定前缀名必须小写
* 在项目开发中，属性与参数的绑定操作，推荐使用这种方法
 */
@ConfigurationProperties(prefix = "yamlbean")
public class YamlBean {
//  @Value，只能对单个变量绑定属性值
    private String magic;
    private String message;
    private User user;
    private Map<String,Object> map;
    private String array[];
    private List<Object> list;
}
```

### 单元测试示例：

```java
@SpringBootTest
class SpringBootMyBatisApplicationTests {
    @Autowired
//  或者@Resource
    private YamlBean yamlBean;
    @Test
    public void yamlBeanTest(){
        System.out.println(yamlBean.getMagic());
        System.out.println(yamlBean.getMessage());
        System.out.println("-----------------");
        System.out.println(yamlBean.toString());
    }
}
```

**注意点：映射的属性名必须要和yml配置文件中的键名一致**

## yaml开发环境配置

一个项目从立项到上线，可以简单的概括为三个阶段：开发阶段（dev）、测试阶段（test）、生产阶段（prod），不同阶段可以配置不同的配置文件，具体的实现方式：

1.在项目中构建不同的yml配置文件

application-test.yml

application-prod.yml

2.配置环境，激活配置文件

在对应配置文件中指定环境 application-test.yml

```
#测试阶段
server:
  port: 9100

spring:
  config:
    activate:
      on-profile:test #指定当前测试环境
```



在主配置文件中激活指定的环境 application-test.yml

```
spring:
  config:
    active: test #指定当前激活指定的环境
```

## SpringBoot数据源

SpringBoot默认支持常用的数据源操作，其定义在

常用连接池：Hikar、C3P0、DBCP2、Druid

**加载数据源依赖：**

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starterjdbc</artifactId>
</dependency>
<dependency>
    <groupId>mysql</groupId>
    <artifactId>mysql-connector-java</artifactId>
</dependency>
```

**配置连接：**

连接池

数据源

## SpringBoot整合MyBatis

1.创建SpringBoot项目，导入持久层相关依赖

```
<dependencies>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-activemq</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-amqp</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-data-redis</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-quartz</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-thymeleaf</artifactId>
    </dependency>
    <!--SpringMVC 依赖-->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    <dependency>
        <groupId>org.mybatis.spring.boot</groupId>
        <artifactId>mybatis-spring-boot-starter</artifactId>
        <version>2.1.4</version>
    </dependency>
    <dependency>
        <groupId>org.springframework.kafka</groupId>
        <artifactId>spring-kafka</artifactId>
    </dependency>
    <!--热启动依赖,原生依赖-->
    <!--<dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-devtools</artifactId>
        <scope>runtime</scope>
        <optional>true</optional>
    </dependency>-->
    <!--连接池依赖-->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-jdbc</artifactId>
    </dependency>
    <!--Druid依赖-->
    <dependency>
        <groupId>com.alibaba</groupId>
        <artifactId>druid</artifactId>
        <version>1.1.23</version>
    </dependency>
    <!--mysql依赖-->
    <dependency>
        <groupId>mysql</groupId>
        <artifactId>mysql-connector-java</artifactId>
        <scope>runtime</scope>
    </dependency>
    <!--Spring Data JPA依赖-->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-data-jpa</artifactId>
    </dependency>
    <dependency>
        <groupId>org.projectlombok</groupId>
        <artifactId>lombok</artifactId>
        <optional>true</optional>
    </dependency>
    <!--单元测试-->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-test</artifactId>
        <scope>test</scope>
        <exclusions>
            <exclusion>
                <groupId>org.junit.vintage</groupId>
                <artifactId>junit-vintage-engine</artifactId>
            </exclusion>
        </exclusions>
    </dependency>
    <dependency>
        <groupId>org.springframework.amqp</groupId>
        <artifactId>spring-rabbit-test</artifactId>
        <scope>test</scope>
    </dependency>
    <dependency>
        <groupId>org.springframework.kafka</groupId>
        <artifactId>spring-kafka-test</artifactId>
        <scope>test</scope>
    </dependency>
</dependencies>
```

2.创建程序目录

在项目目录下创建目录

- controller

​		Controller层负责具体业务模块流程的控制

- entity(pojo)

​		主要用于存放实体类，与数据库表中的字段基本保持一致，实现映射

- dao

​		主要是做数据持久层的工作，负责与数据库联系，封装基本的CRUD操作

- service

​		主要负责业务模块的逻辑应用设计，具体就是调用Dao层定义接口

分析

​	service建立在Dao层之上，建立了Dao层之后才可以建立service层，service层又是在controller层之下，service层调用Dao层接口，又提供给controller层进行控制处理

从客户端的角度：

​	用户从页面访问，也就是view层进行查询访问，进入controller层并找到对应的接口，controller层对service层进行业务功能的调用，service层调用Dao层数据库，Dao层调用mapper.xml映射文件生成SQL语句到数据库中进行查询（请求过程）

​	在数据库中查询到数据，Dao层拿到实体对象数据，交付给service层，service层进行业务逻辑的处理，返回结果给controller层，controller根据结果进行最后一步处理（视图匹配），将查询结果返回给前端页面（响应过程）



pom.xml

application.properties

```
#配置服务端口
server.port=8081
#数据库驱动
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
#指定数据库连接地址
spring.datasource.url=jdbc:mysql://localhost:3306/mybatis
#连接数据库用户名和密码
spring。datasource.username=root
spring。datasource.password=root
```

application-dev.yml

```
#开发阶段
spring:
  config:
    active: 
    	on-profile: dev #指定当前开发环境
    	
  datasource:
  	driver-class-name:com.mysql.cj.jdbc.Driver
  	url:jdbc:mysql://localhost:3306/mybatis
  	username:root
  	password:root
```

##### 第三方连接池的配置

阿里Druid连接池

1.加载依赖

```
<!--        druid依赖-->
        <dependency>
            <groupId>com.alibaba</groupId>
            <artifactId>druid</artifactId>
            <scope>1.1.23</scope>
        </dependency>
```

2.配置连接

application-prod.yml

```
#生产阶段
spring:
  config:
    active: 
    	on-profile: prod #指定当前开发环境
    	
  datasource:
  	driver-class-name:com.mysql.cj.jdbc.Driver
  	url:jdbc:mysql://localhost:3306/mybatis
  	username:root
  	password:root
  	type:com.alibaba.druid.pool.DruidDataSource
  	
  	druid:
  		driver-class-name:com.mysql.cj.jdbc.Driver
  		url:jdbc:mysql://localhost:3306/mybatis
  		username:root
  		password:root
  		db-type:com.alibaba.druid.pool.DruidDataSource
```

## Spring Data JPA

JPA:全称Java Persistence API,可以通过注解或者XML描述[对象-关系表]之间的映射关系，并将实体对象持久化到数据库中。

##### jpa的特点

ORM映射元数据:支持XML和注解两种元数据的形式，元数据描述对象和表之间的映射关系（实体类映射成数据库表）

API: 操作实体对象来执行CRUD操作

查询语言:通过面向对象而非面向数据库的查询语言(JPQL) 查询数据，避免程序的SQL语句紧密耦合

spring data jpa是对jpa的封装，在JPA之上添加另一层抽象(Repository层的实现) ， 极大地简化持久层开发及ORM框架切换的成本。

Spring Data JPA依赖

```
<!--Spring Data JPA依赖-->
    <dependency>
    	<groupId>org. springframework.boot</ groupId>
    	<artifactId>spring-boot-starter-data-jpa</artifactId>
    </dependency>
```

## ORM映射

在Spring Data JPA中通过JPA（标准）相关的注解可以将实体类映射成数据表

## Spring Data jPA核心接口

在Spring Data JPA中提供了一-些常 用的接口来完成对数据库的操作

1. CrudRepository: 常规的CRUD的操作I
2. PageAndSortingRepository: 分页和排序的操作
3. JpaRepository继承了PageAndSortingRepository
4. Pepository:进行定制化操作，可以提供：
   1. 基于方法名称命名查询
   2. 基于@query注解查询与更新

分析:

通过对底层代码的分析发现，JpaRepository继承PageAndSortingRepository, PageAndSortingRepository继承CrudRepository, 所以在实际开发中只需要继承JpaRepository接口即可，就能完成相关的CRUD、分页、排序的操作

##### JpaRepository接口

需求：对数据库表进行添加、修改、删除、列表查询、排序等操作

分页查询默认初始页是从0页开始



##### Repository接口



##### 自定义操作

在Spring Data JPA中只是封装了常规的CRUD以及分页排序的操作，对于复杂的业务，则需要进行自定义操作，spring Data JPA中提供2中自定义操作的实现

1.基于方法名称命名查询

2.基于@query注解查询与更新

##### 方法名称命名查询

方法名称命名查询必须要遵循驼峰式命名规则：

> findBy(关键字)+属性名（首字母大写）+查询条件（首字母大写）

需求：

```
    登录操作（条件查询）
    根据用户名进行模糊查询
    根据性别进行统计操作
```

##### @query

@query基于注解的操作，需要知道使用JPQL语句，相当于基于实体类的查询来进行数据库表记录的映射。

```
//    根据id查询
//    注意点：基于实体类的查询操作，类名一定要大写 使用别名，条件对应实体类中属性名
    @Query(value = "select emp from EmpJPATest emp where emp.id=?1 and emp.username=?2") //JPQL语句
    public EmpJPATest findByEmpId(String id,String username);
}
```

JPQL语句使用占位符[?]参数索引，索引从1开始，注解查询方式传参有两种方式：

1.[?]方法参数索引，Eg:?1\?2

2.[:]参数名，参数名必须是实体的属性，并且方法上的形参要加上注解



注意点:JPQL参数名称必须是实体的属性@Param("pwd") String pwd 注解中的属性值要与JPQL语句中的参数一致。

基于注解的操作支持delete、update，不支持insert

## SpringBoot整合Web应用

在前面的项目过程中知道视图的处理时通过SpringMVC框架来完成，并且通过模板（Thymeleaf）做视图层数据的展示。SpringMVC框架时SPringle框架的一个模块，其可以与Spring框架无缝对接进行整合，是一个基于MVC的web视图层框架。

MVC:

MVC模型（model-view-controller）：是软件工程中的一种软件架构模型

1.导入Web依赖



```
@RequestMapping(value = "/index", method = RequestMethod.GET)
public String helloWorld(){
    System.out.println("===控制器视图映射匹配===");
    return "hello，开始学习视图层的控制操作！！！";
}
```

*RESTFUL*
get与post区别
1.post比get更安全
2.get请求中请求参数会在URL中显示，post不会
3.get请求有长度限制，post没有
4.get请求url地址会跳转，post请求url地址不变

@RequestMapping用于URL请求与控制器中方法的映射

状态码

| 状态码 | 对应状态       |
| ------ | -------------- |
| 202    | 请求成功       |
| 404    | 请求地址错误   |
| 405    | 请求类型不匹配 |
| 500    | 业务逻辑错误   |

## 模板引擎

SpringBoot开发web应用视图映射返回的servlet，其不便于对页面的操作，如果要想把处理的结果渲染到网页（html页面）上，这是就需要使用模板，在SpringBoot中提供了相关默认支持的模板引擎：Thymeleaf、FreeMarker、Velocity、Groovy，在SpringBoot中不推荐使用jsp

## Thymeleaf模板

Thymeleaf是一款用于XML/XHTML/HTML5内容的模板引擎，类似html、jsp、FreeMarker，可以轻易与SpringMVC等web视图层框架进行集成。其最大的特点是能够在有网络或无网络的环境下直接在浏览器中打开并正确显示模板页面。

1.引入Thymeleaf模板依赖

```
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-thymeleaf</artifactId>
</dependency>
```

2.配置Thymeleaf模板相关配置项，在项目开发中，可以使用默认配置项

```
thymeleaf:
  cache: false #开发阶段关闭页面缓存，生产阶段再开启
  mode: HTML5
  suffix: .html #视图页面的后缀名
  prefix: classpath:/templates/ #模板页面的路径
  encoding: UTF-8 #指定页面字符集
  servlet:
    content-type: text/html #页面类型
```

3.controller页面映射

```
//    controller传递参数到视图页面的方式：Model、ModelAndView、request、session（全局）
//    请求URL:http://127.0.0.0(localhost):8080/user/index
    @RequestMapping(value = "/index",method = RequestMethod.GET)
    public String index(Model model,HttpServletRequest request){
        HttpSession session = request.getSession();
        session.setAttribute("sessionMsg","session对象传值操作");
        request.setAttribute("reqMsg","request对象传值操作");
        model.addAttribute("msg","Model对象传值操作");
        return "index"; //index.html ==> 视图名称
    }

//    通过ModelAndView对象传递值
//    请求URL:http://127.0.0.0(localhost):8080/user/mvIndex
    @RequestMapping(value = "mvIndex", method = RequestMethod.GET)
    public ModelAndView modelAndViewIndex(){
        ModelAndView mv = new ModelAndView();
        mv.addObject("mvMsg","ModelAndView对象传值操作");
        mv.setViewName("index");
        return mv;
    }
```

index.html

```
<body>
    <h2 th:text="${msg}">Model对象传值操作</h2>
    <hr>
    <h2 th:text="${reqMsg}">request对象传值操作</h2>
    <hr>
    <h2 th:text="${session.sessionMsg}">session对象传值操作</h2>
    <hr>
    <h2 th:text="${mvMsg}">mvMsg对象传值操作</h2>
</body>
```

http://127.0.0.0(localhost):8080/user/index

​	可以看到

​	Model对象传值操作
​	request对象传值操作
​	session对象传值操作

http://127.0.0.0(localhost):8080/user/mvIndex

​	可以看到

​	session对象传值操作（因为是全局，所以在其他页面也可以看到）
​	ModelAndView对象传值操作

4.构造模板页面

```
<!DOCTYPE html>
<html lang="en" xmlns:th="http://www.thymeleaf.org"><!--在页面加载Thymeleaf模板标签-->
<head>
    <meta charset="UTF-8">
    <title>初始化页面</title>
</head>
<body>
    <h2 style="color: #dc143c">SpringBoot综合项目架构基于Thymeleaf</h2>
    <h2 th:text="${msg}">Model对象传值操作</h2>
    <hr>
    <h2 th:text="${reqMsg}">request对象传值操作</h2>
    <hr>
    <h2 th:text="${session.sessionMsg}">session对象传值操作</h2>
    <hr>
    <h2 th:text="${mvMsg}">mvMsg对象传值操作</h2>
    <img width="400px" height="400px" src="../static/1.jpg">

</body>
</html>
```

注意：在页面使用Thymeleaf模板标签，必须要先在页面加载标签项

> <html lang="en" xmlns:th="http://www.thymeleaf.org"><!--在页面加载Thymeleaf模板标签-->

##### 综合应用

需求：数据（CRUD）操作

1.操作POJO类

2.编写Mapper接口

3.Mapper接口对应的映射文件

4.创建service层接口

5.编写Controller控制器

6.构造视图页面

7.数据渲染

8.单元测试



## SpringBoot整合Thymeleaf模板

##### 





## Shiro

Shir简单来说就是一个安全框架， 在项目开发中进行权限管理的操作,它可以帮助我们在开发中快速、容易的实现认证、授权的相关功能。
权限管理:基本上涉及到用户参与的系统都要进行权限管理，权限管理属于系统安全的范畴，权限管理实现对用户访问系统的控制，按照安全规则或者安全策略控制用户可以访问而且只能访问自己被授权的资源。
认证(Authentication):也就是我们平时所说的登录.判断一个用户是否为合法用户的外理讨程.最常用的简单身份认证方式系统











